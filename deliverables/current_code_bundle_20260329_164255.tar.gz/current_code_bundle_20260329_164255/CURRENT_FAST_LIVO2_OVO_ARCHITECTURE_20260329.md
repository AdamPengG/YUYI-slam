# 当前项目完整架构与数据流说明

更新时间：2026-03-29

本文档描述当前 `/home/peng/isacc_slam` 工作区里，`Isaac Sim + FAST-LIVO2 + onemap_semantic_mapper + reference/OVO` 这一整套系统的真实运行架构、数据合同、执行顺序、产物目录、已知问题和下一步改造方向。

本文档不是论文设想版，也不是早期离线实验版，而是当前代码实际落地后的“现状文档”。

---

## 1. 当前系统的总目标

当前系统的目标不是让 `OVO` 自己再建一张长期几何真相，而是把职责拆开：

- `Isaac Sim`
  - 提供仿真环境和 ROS2 传感器话题
- `FAST-LIVO2`
  - 作为唯一几何主权威
  - 作为唯一位姿主权威
  - 生成稳定的 LiDAR/RGB 几何地图和 `odom/path/tf`
- `livo2_ovo_keyframe_exporter`
  - 从 `FAST-LIVO2` 导出关键帧图像、深度、相机位姿、局部点云
  - 形成供后续语义观察器使用的 manifests
- `observer_online`
  - 只做 2D 语义分割、3D 点投票、对象记忆
  - 不再负责长期几何地图真相
- `semantic publishers`
  - 把语义观察结果以 ROS topic 形式发到 RViz
- `final_consolidation`
  - 在离线/回环后，把观测与对象记忆整理成最终语义地图

一句话概括：

**FAST-LIVO2 管几何和 pose，OVO 风格模块管语义观察和对象记忆。**

---

## 2. 代码目录与模块边界

### 2.1 Isaac Sim 侧

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/isaac_turtle_stage_runner.py`

职责：

- 打开并修补当前 USD 场景
- 统一 ROS Camera / IMU / LIVO2 graph
- 统一 physics frequency / sensor period / graph topic
- 根据 profile 切换 `livo2` 或 `orb`

当前常用 profile：

- `livo2`
  - 相机发布 `/robot_rgb`、`/depth`、`/camera_info`
  - LiDAR/IMU 发布 `/livox/lidar`、`/livox/imu`

当前资产目录：

- `/home/peng/isacc learned/tutle/turtle.usd`

相关记录文档：

- `/home/peng/isacc_slam/docs/current_isaac_sensor_extrinsics_20260329_office.md`

### 2.2 FAST-LIVO2 侧

- Launch：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/launch/mapping_isaac.launch.py`
- 主配置：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/config/avia_isaac.yaml`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/config/camera_pinhole.yaml`
- 主程序：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/src/LIVMapper.cpp`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/include/LIVMapper.h`

职责：

- 订阅 LiDAR、IMU、RGB 图像
- 执行 LIO/VIO 融合
- 发布点云地图、里程计、路径、TF
- 作为 downstream exporter 的 pose authority 与几何 authority

### 2.3 onemap_semantic_mapper 侧

路径：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper`

当前核心模块：

- `livo2_ovo_keyframe_exporter.py`
  - 导出关键帧、局部点云、位姿、scene config、manifests
- `observer_online.py`
  - 当前在线语义观察主逻辑
- `semantic_observer.py`
  - mask 命中点、已有对象多数投票、ObservationLink 生成
- `visibility_projector.py`
  - local cloud 投影到图像并做深度一致性过滤
- `object_memory.py`
  - 对象记忆与合并
- `ovo_async_worker.py`
  - 后台拉起在线观察器脚本
- `ovo_semantic_map_publisher.py`
  - 发布语义着色点云
- `ovo_semantic_lidar_map_publisher.py`
  - 将语义快照投到 `/cloud_registered`
- `final_consolidation.py`
  - 读取 manifests 和 observation，输出最终语义地图

### 2.4 reference/OVO 侧

路径：

- `/home/peng/isacc_slam/reference/OVO`

在当前系统里的角色已经收缩为：

- 复用 OVO 的语义子模块思想与部分实现
- 提供 class/eval/config 基线
- 不再作为在线 working geometry 真相

当前主线已经不依赖旧的：

- `reference/OVO/run_online_incremental.py`

而改为使用：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/run_semantic_observer_online.py`

---

## 3. 启动链路与进程关系

### 3.1 标准启动顺序

#### 1. Isaac Sim

命令：

```bash
cd /home/peng/isacc_slam
env -u PYTHONPATH -u AMENT_PREFIX_PATH -u COLCON_PREFIX_PATH -u CMAKE_PREFIX_PATH -u CONDA_PREFIX -u CONDA_DEFAULT_ENV -u CONDA_PROMPT_MODIFIER \
/home/peng/IsaacSim/_build/linux-x86_64/release/python.sh \
/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/isaac_turtle_stage_runner.py \
--usd_path '/home/peng/isacc learned/tutle/turtle.usd' \
--profile livo2
```

#### 2. FAST-LIVO2 + RViz

```bash
cd /home/peng/isacc_slam
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch fast_livo mapping_isaac.launch.py use_rviz:=True
```

#### 3. 在线语义链

```bash
cd /home/peng/isacc_slam
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch onemap_semantic_mapper ovo_async_livo2.launch.py \
  use_rviz:=False \
  launch_fast_livo:=False \
  scene_name:=your_scene \
  experiment_name:=your_experiment \
  clear_output_on_start:=True \
  resume_if_exists:=False
```

### 3.2 为什么 `ovo_async_livo2.launch.py` 现在要先清旧节点

当前 launch 文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/launch/ovo_async_livo2.launch.py`

已经加入了启动前清理：

- `ovo_async_worker`
- `ovo_semantic_map_publisher`
- `ovo_semantic_lidar_map_publisher`
- `run_semantic_observer_online.py`

原因：

- 以前同名残留 OVO 节点会继续发布旧快照
- 导致即使只起了 `LIVO2`，`/ovo_semantic_map` 也会出现“幽灵语义图”

现在 launch 先 `pkill`，再延迟 1 秒拉新节点，避免旧 publisher 和新 publisher 并存。

---

## 4. Isaac Sim 传感器层架构

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/isaac_turtle_stage_runner.py`

### 4.1 相机链

相机 graph 路径：

- `/World/turtlebot3_burger_ROS/ROS_Camera`

相机 prim：

- `/World/turtlebot3_burger_ROS/base_scan/Camera1`

发布：

- `/robot_rgb`
- `/depth`
- `/camera_info`

关键参数：

- 图像尺寸：`1280 x 720`
- `frameSkipCount = 3`
- `queueSize = 1`
- `qosProfile = Sensor Data`

### 4.2 IMU 链

IMU graph 路径：

- `/World/turtlebot3_burger_ROS/ROS_IMU`

当前 `livo2` profile 下 IMU 话题：

- `/livox/imu`

关键参数：

- `PHYSICS_FREQUENCY = 120`
- `IMU_SENSOR_PERIOD = 1/120`
- `IMU_PUBLISH_STEP = 1`
- IMU frame：`sim_imu`

### 4.3 LiDAR 链

LIVO2 graph 路径：

- `/World/turtlebot3_burger_ROS/ROS__Lidar`

当前 `livo2` profile 下发布：

- `/livox/lidar`
- `/livox/imu`

系统还会清理旧的相机发布节点，避免 `/rgb` 和重复 `/camera_info` 继续存在。

### 4.4 profile 的作用

`PROFILE_CONFIG` 当前支持：

- `livo2`
  - LiDAR + IMU + RGB-D 全开
  - 不禁用 lidar prim
- `orb`
  - IMU 改发 `/orb_slam3/imu`
  - 关闭 lidar 相关 prim/graph

---

## 5. FAST-LIVO2 的运行职责

文件：

- `/home/peng/isacc_slam/src/FAST-LIVO2/src/LIVMapper.cpp`

### 5.1 输入

来自 `avia_isaac.yaml`：

- `common.img_topic = /robot_rgb`
- `common.lid_topic = /livox/lidar`
- `common.imu_topic = /livox/imu`

### 5.2 当前关键外参配置

文件：

- `/home/peng/isacc_slam/src/FAST-LIVO2/config/avia_isaac.yaml`

当前值：

- `extrinsic_T = [0.0, 0.0, 0.790440008]`
- `extrinsic_R = I`
- `Rcl = [[0,-1,0],[0,0,-1],[1,0,0]]`
- `Pcl = [0.0, 0.0, 0.0]`

含义：

- `extrinsic_T/R`：IMU 与 LiDAR 关系
- `Rcl/Pcl`：LiDAR 与 camera 关系

### 5.3 当前发布时间戳策略

`LIVMapper.cpp` 里已经改成：

- 点云 `/cloud_registered`
- 里程计 `/aft_mapped_to_init`
- 路径 `/path`
- 图像 republish

统一使用 `current_output_stamp()`，优先取：

1. `LidarMeasures.last_lio_update_time`
2. `latest_ekf_time`
3. `last_timestamp_lidar`
4. `last_timestamp_img`
5. `last_timestamp_imu`

只有实在没有传感器时间，才退回 ROS wall time。

这一步是之前为了解决：

- exporter 对齐误差大
- 关键帧 pose 和 RGB/Depth 不在同一时间轴

### 5.4 主要输出话题

当前主输出：

- `/cloud_registered`
- `/aft_mapped_to_init`
- `/path`
- TF：`camera_init -> aft_mapped`

注意：

- `/cloud_registered` 才是当前真正持续发布、被 RViz 主显示使用的地图点云
- `/Laser_map` 在代码里创建过 publisher，但不是当前稳定主显示源

---

## 6. exporter：从 FAST-LIVO2 到语义观察器的数据合同

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/livo2_ovo_keyframe_exporter.py`

### 6.1 exporter 的职责

它做 4 件事：

1. 订阅并缓存：
   - `/robot_rgb`
   - `/depth`
   - `/camera_info`
   - `/aft_mapped_to_init`
   - `/cloud_registered`
2. 做时间对齐：
   - image / depth / odom / local cloud 对齐
   - 必要时做 pose 插值
3. 做关键帧选择：
   - translation
   - rotation
   - coverage novelty
   - max time gap
4. 同时输出：
   - OVO 兼容的 scene 目录
   - 当前新观察器使用的 run-local manifests

### 6.2 关键帧选择规则

当前规则：

- 质量门控：
  - `pose present`
  - `timestamp monotonic`
  - `depth valid ratio`
  - `blur score`
- 触发器：
  - `translation`
  - `rotation`
  - `coverage`
  - `time`

当前默认阈值：

- `translation_thresh_m = 0.35`
- `rotation_thresh_deg = 10.0`
- `depth_valid_ratio_thresh = 0.55`
- `blur_score_min = 30.0`
- `coverage_novelty_thresh = 0.20`
- `max_time_gap_sec = 2.0`

### 6.3 exporter 的两套输出

#### A. Scene 级 OVO 兼容目录

位于：

- `reference/OVO/data/input/Datasets/Replica/<scene_name>/`

包含：

- `results/frame*.jpg`
- `results/depth*.png`
- `traj.txt`
- `frames_index.csv`
- `sensor_config.yaml`
- scene config yaml
- `local_clouds/local_cloud_*.npz`

#### B. Run 级稳定工件目录

位于：

- `runs/ovo_pose_keyframes/<run_id>/export/`

包含：

- `results/frame*.jpg`
- `results/depth*.png`
- `local_clouds/local_cloud_*.npz`
- `keyframe_packets.jsonl`
- `local_cloud_packets.jsonl`
- `keyframes.jsonl`
- `session.json`

### 6.4 为什么需要 run-local 稳定路径

原因：

- scene 目录可能被下一轮录制覆盖
- 在线观察器不能依赖一个会被重录覆盖的路径

所以现在 exporter 会把图片、深度和 local cloud 再镜像到 `run/export` 下，供观察器稳定消费。

### 6.5 关键数据结构

定义在：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/data_types.py`

当前使用：

- `SensorConfig`
- `KeyframePacket`
- `LocalCloudPacket`
- `ObservationLink`
- `ObjectMemory`

---

## 7. 在线语义观察器主链

### 7.1 在线入口

脚本：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/run_semantic_observer_online.py`

真正逻辑：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/observer_online.py`

### 7.2 当前 observer_online 的工作步骤

1. 读取：
   - `keyframe_packets.jsonl`
   - `local_cloud_packets.jsonl`
   - `sensor_config.yaml`
2. 逐个处理新 keyframe
3. 对当前 keyframe：
   - 读取 RGB
   - 读取 Depth
   - 读取 local cloud
4. 用 `VisibilityProjector` 把 local cloud 投到当前图像
5. 用 `OnlineSemanticAdapter`：
   - 调 OVO 的 SAM mask generator
   - 调 OVO 的 CLIP 文本匹配
   - 生成当前帧的 `MaskObservation`
6. 用 `SemanticObserver`：
   - 对 mask 内命中的点做统计
   - 用 `existing_point_object_ids` 做已有对象多数投票
   - 生成 `ObservationLink`
7. 用 `ObjectMemoryStore` 更新对象记忆
8. 定期导出：
   - `semantic_snapshot.npz`
   - `object_memory.json`
   - `online_status.json`
   - `observation_links.jsonl`

### 7.3 这条链现在为什么比旧 OVO working map 更接近目标

以前：

- `reference/OVO/run_online_incremental.py`
- OVO 自己长期积 geometry + semantic

现在：

- geometry authority 在 `FAST-LIVO2`
- 观察器只消费 `keyframe packet + local cloud packet`
- 对象记忆只记录语义支持关系

这就是当前架构最核心的切换。

---

## 8. VisibilityProjector：图像与点云可见性桥

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/visibility_projector.py`

### 8.1 输入

- `KeyframePacket`
- `LocalCloudPacket`
- `SensorConfig`
- `depth_m`

### 8.2 处理

- 把 local cloud 视为世界系点
- 用 `T_world_cam` 反变换到当前相机系
- 用 `fx/fy/cx/cy` 投影到像素
- 仅保留：
  - 在图像内
  - 在相机前方
  - 深度与当前 depth 一致
  - 同像素只保留最近一点

### 8.3 当前已做的关键修正

现在默认深度容差已经从 `0.08m` 收紧到：

- `0.03m`

目的：

- 减少前景植物通过叶片缝隙把背景墙点一起吸进来

---

## 9. SemanticObserver：mask 命中点与实例投票

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/semantic_observer.py`

### 9.1 当前逻辑

对每个 mask：

1. 检查 `mask_area`
2. 取 mask 内的投影点
3. 如果命中点太少，丢弃
4. 若给了 `existing_point_object_ids`
   - 对命中点已有对象归属做多数投票
   - 生成 `candidate_object_id`
5. 生成 `ObservationLink`

### 9.2 当前新修正

这一轮已经加了：

- `mask_erosion_px`
- 默认 `2px`

作用：

- 对 mask 边缘做轻度腐蚀
- 减少植物、栏杆、椅子腿这类细结构把背景误吸进去

### 9.3 当前仍未彻底解决的问题

虽然现在已经把 `existing_point_object_ids` 接上了，但还缺更强的：

- label-aware object merge
- 污染 support points 的重分配/剔除

所以“植物后墙污染”问题只能减轻，不能彻底根治。

---

## 10. ObjectMemory：对象记忆与实例维护

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/object_memory.py`

### 10.1 当前存什么

每个对象保存：

- `object_id`
- `point_support_refs`
- `centroid_world`
- `bbox_world`
- `label_votes`
- `best_view_keyframes`
- `observation_count`
- `stability_score`
- `completeness_score`
- `last_seen_stamp`

### 10.2 当前合并规则

如果观察没有明确 `candidate_object_id`，会退回：

- 质心距离最近
- 且小于 `merge_centroid_radius_m`

当前默认：

- `merge_centroid_radius_m = 0.75`

### 10.3 当前已加的新能力

新增：

- `point_object_ids_for_local_cloud(local_cloud_id, point_count)`

作用：

- 从历史 `point_support_refs` 反推出当前 local cloud 每个点已经属于哪个对象
- 供 `SemanticObserver` 做已有点多数投票

### 10.4 当前已知局限

当前对象记忆仍然是“增量记忆”，不是“可逆纠错记忆”：

- 一旦错误点进入某对象的 `point_support_refs`
- 后续不会自动从该对象中移除

这就是“语义污染会残留”的核心原因。

---

## 11. 在线输出与 RViz 显示层

### 11.1 `/ovo_semantic_map`

节点：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_map_publisher.py`

输入：

- `semantic_snapshot.npz`

输出：

- `/ovo_semantic_map`
- `/ovo_instance_labels`

内容：

- 语义着色点云
- 实例标签文字

### 11.2 `/ovo_semantic_lidar_map`

节点：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_lidar_map_publisher.py`

输入：

- `semantic_snapshot.npz`
- `/cloud_registered`

处理：

- 用 `cKDTree` 在 OVO 语义快照点和当前 `/cloud_registered` 之间做近邻投票

输出：

- `/ovo_semantic_lidar_map`
- `/ovo_instance_labels_lidar`

### 11.3 当前显示语义

当前 RViz 里应该区分：

- `/cloud_registered`
  - RGB 着色几何地图
- `/ovo_semantic_map`
  - 语义着色点云 working map
- `/ovo_semantic_lidar_map`
  - 语义投到当前 LiDAR 点云后的显示图

### 11.4 为什么以前会出现“幽灵语义点云”

原因有两类：

1. 残留旧 publisher 没杀掉
2. worker 误用了旧 run 的 export manifests

当前已修：

- launch 启动前先 `pkill` 同名 OVO 节点
- worker 只接受本轮新的 `session.json`，除非 `resume_if_exists:=True`
- publisher 启动会优先清空旧缓存显示

---

## 12. 最终整合 Final Consolidation

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/final_consolidation.py`

当前作用：

- 读取：
  - `keyframe_packets.jsonl`
  - `local_cloud_packets.jsonl`
  - `observation_links.jsonl`
- 把 observation 对应的点云 support 提出来
- 输出：
  - `*_semantic_cloud.ply`
  - `*_objects.json`
  - `*_hydra_nodes_edges.json`
  - `*_summary.json`

当前它还是“第一版整合器”，还没有实现：

- 强平面融合
- 同类对象拓扑清理
- 历史污染 support 剔除

所以它是可用的，但还不是论文级最终地图。

---

## 13. 当前与原始 OVO 的关系

### 13.1 复用了什么

- SAM mask 生成
- CLIP 文本匹配思路
- “mask 命中点 -> 实例候选”的观察思路
- 多视角对象记忆与标签投票思路

### 13.2 没继续用什么

- 旧的 OVO 全局 working geometry 真相
- 旧的 `run_online_incremental.py` 在线主链

### 13.3 当前与 OVO 原版相比还缺什么

最重要的两件：

1. **已有 3D 点多数投票虽然接上了，但还不够强**
   - 还缺真正的点级重分配和污染清洗
2. **对象合并过于几何化**
   - 当前主要靠质心距离
   - 还没有做到 OVO 那种“点重叠 + 语义兼容 + 多视角稳定性”联合判定

---

## 14. 当前已知问题清单

### 14.1 植物污染后墙

表现：

- 前景植物识别出来后，后方整片墙也被染成植物

当前已确认根因：

- depth tolerance 以前太宽
- mask 边缘未腐蚀
- 历史对象 support 点不支持清洗
- object merge 还不是 label-aware

当前已做：

- depth tolerance 收到 `0.03m`
- mask erosion 默认 `2px`
- `existing_point_object_ids` 已接上

还没做：

- 被污染 support points 的重分配/剔除
- label-aware merge

### 14.2 旋转时语义图分层

表现：

- 墙和地面在旋转过程中出现多层壳

根因：

- 语义 working map 仍然是 RGB-D / local cloud 观察结果的历史累计
- 不是最终强融合后的几何真相

所以：

- `FAST-LIVO2` 自己看着稳
- `OVO semantic map` 仍然会显得厚、散、分层

### 14.3 “幽灵语义图”

表现：

- 没采新数据，启动后就有 `/ovo_semantic_map`

根因：

- 旧 worker/old publishers 残留
- worker 回收了旧 export

当前已修。

### 14.4 启动时 ghost lidar frame

表现：

- `FAST-LIVO2` 刚起时，RViz 会看到一帧类似幽灵点云

原因更像：

- 真实第一批 LiDAR 帧已经到了
- RViz 的 `/cloud_registered` 长衰减显示把它留住了

这不是语义问题，是 RViz display 行为。

---

## 15. 当前最重要的运行文件合同

### 15.1 scene 目录

例如：

- `reference/OVO/data/input/Datasets/Replica/<scene_name>/`

必须有：

- `results/frame*.jpg`
- `results/depth*.png`
- `traj.txt`
- `sensor_config.yaml`

### 15.2 run/export 目录

例如：

- `runs/ovo_pose_keyframes/<run_id>/export/`

必须有：

- `keyframe_packets.jsonl`
- `local_cloud_packets.jsonl`
- `results/frame*.jpg`
- `results/depth*.png`
- `local_clouds/*.npz`
- `session.json`

### 15.3 output 目录

例如：

- `reference/OVO/data/output/Replica/<experiment_name>/<scene_name>/`

典型内容：

- `semantic_snapshot.npz`
- `semantic_snapshot_summary.txt`
- `object_memory.json`
- `online_status.json`

---

## 16. 当前在线主链的真实执行顺序

1. `Isaac Sim` 发布：
   - `/robot_rgb`
   - `/depth`
   - `/camera_info`
   - `/livox/lidar`
   - `/livox/imu`
2. `FAST-LIVO2` 消费传感器，发布：
   - `/cloud_registered`
   - `/aft_mapped_to_init`
   - `/path`
   - TF
3. `livo2_ovo_keyframe_exporter` 对齐：
   - image/depth/odom/local_cloud
   - 选关键帧
   - 写：
     - `frame/depth/traj`
     - `keyframe_packets/local_cloud_packets`
4. `ovo_async_worker`
   - 监视 export 目录
   - 启动 `run_semantic_observer_online.py`
5. `observer_online`
   - 读取 manifests
   - 调 SAM/CLIP
   - 生成 `ObservationLink`
   - 更新 `ObjectMemory`
   - 导出 `semantic_snapshot.npz`
6. `ovo_semantic_map_publisher`
   - 发布 `/ovo_semantic_map`
7. `ovo_semantic_lidar_map_publisher`
   - 用当前 `/cloud_registered` 把语义近邻投上去
   - 发布 `/ovo_semantic_lidar_map`

---

## 17. 当前最值得继续改的地方

按照优先级，我认为后续开发顺序应该是：

### 17.1 第一优先级

- label-aware object merge
- 污染 support points 的剔除/重分配

这是解决“植物污染后墙”的核心。

### 17.2 第二优先级

- 让 `/ovo_semantic_lidar_map` 真正成为在线主显示
- `/ovo_semantic_map` 退为 debug working map

这样更符合“FAST-LIVO2 几何主权威”原则。

### 17.3 第三优先级

- 增强 `final_consolidation`
  - 主连通块保留
  - 小碎片清理
  - 同类对象二次融合
  - 结构面清理

### 17.4 第四优先级

- 给对象记忆增加更显式的“脏点回滚 / 重新投票”机制

---

## 18. 当前结论

当前项目已经从：

- “OVO 自己累计几何 + 语义”

切到：

- “FAST-LIVO2 提供几何和 pose 主权威”
- “observer_online 做语义观察和对象记忆”
- “publishers 负责在线显示”
- “final_consolidation 负责最终结果”

但当前系统仍处于：

**主架构已经切对，语义观察精度与对象去污染机制还在继续收敛。**

这是现在最准确的阶段判断。

