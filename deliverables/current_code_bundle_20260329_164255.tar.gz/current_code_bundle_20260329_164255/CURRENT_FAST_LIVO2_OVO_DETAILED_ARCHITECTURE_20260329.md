# 当前 FAST-LIVO2 + OVO 语义观察器项目的完整细粒度架构说明

更新时间：2026-03-29 16:42:55

本文档描述当前 `/home/peng/isacc_slam` 工作区中，`Isaac Sim + FAST-LIVO2 + onemap_semantic_mapper + reference/OVO` 这一整套系统的真实架构、运行流程、目录合同、函数职责、数据流向、已做改造、当前已知问题与下一步改造方向。

这不是论文设想版，也不是最早的离线实验说明，而是**当前代码实际落地状态**的细化说明。

---

## 1. 当前系统目标与边界

当前系统的目标已经从“让 OVO 自己维护一张长期几何真相地图”收缩为：

- `Isaac Sim`
  - 提供仿真场景和 ROS2 传感器流
- `FAST-LIVO2`
  - 作为**唯一几何主权威**
  - 作为**唯一位姿主权威**
  - 实时输出 LiDAR/RGB 配准地图和 odom/path/tf
- `livo2_ovo_keyframe_exporter`
  - 从 `FAST-LIVO2` 输出中截取关键帧
  - 导出 RGB、Depth、关键帧位姿、局部点云、sensor config、manifests
- `observer_online`
  - 基于关键帧图像做 2D 语义观测
  - 把语义观测投到关键帧局部点云
  - 维护对象记忆 `ObjectMemory`
  - 导出当前工作态语义快照 `semantic_snapshot.npz`
- `semantic publishers`
  - 把语义快照发到 ROS / RViz
- `final_consolidation`
  - 在离线或回环后，读取 manifests + observation + object memory 生成最终地图

一句话概括：

**FAST-LIVO2 管几何和 pose，OVO 风格模块只管语义观察、对象记忆和语义快照。**

当前还没有完全实现的目标：

- 语义状态真正完全跟随 `FAST-LIVO2` 连续几何主图动态回写
- 对污染历史点的全局空间级彻底清洗
- 类似论文图那种干净、闭环后稳定的最终语义地图

---

## 2. 当前项目主目录与职责划分

### 2.1 工作区与 Git 基线

- 工作区：`/home/peng/isacc_slam`
- Git 仓库基线：`/home/peng/YUYI-slam`

当前开发是在 `isacc_slam` 中进行，必要时同步到 `YUYI-slam` 提交并推送。

### 2.2 Isaac Sim 侧

关键脚本：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/isaac_turtle_stage_runner.py`

当前常用资产：

- `/home/peng/isacc learned/tutle/turtle.usd`

职责：

- 打开场景
- 统一传感器 graph
- 配置 `livo2` 或 `orb` profile
- 修补 topic、sensor prim、physics 参数

### 2.3 FAST-LIVO2 侧

关键文件：

- Launch：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/launch/mapping_isaac.launch.py`
- 配置：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/config/avia_isaac.yaml`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/config/camera_pinhole.yaml`
- 主程序：
  - `/home/peng/isacc_slam/src/FAST-LIVO2/src/LIVMapper.cpp`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/include/LIVMapper.h`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/src/vio.cpp`
  - `/home/peng/isacc_slam/src/FAST-LIVO2/src/visual_point.cpp`

职责：

- 订阅 LiDAR、IMU、RGB 图像
- 做 LIO/VIO 融合
- 输出 `/cloud_registered`、`/aft_mapped_to_init`、`/path`
- 作为 exporter 的几何和位姿权威

### 2.4 onemap_semantic_mapper 侧

关键文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/livo2_ovo_keyframe_exporter.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/data_types.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/observer_online.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/semantic_observer.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/visibility_projector.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/object_memory.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_async_worker.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_map_publisher.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_lidar_map_publisher.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/launch/ovo_async_livo2.launch.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/run_semantic_observer_online.py`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/final_consolidation.py`

职责：

- 导出关键帧合同
- 在线语义观察
- 对象记忆
- 语义快照生成
- RViz 语义发布

### 2.5 reference/OVO 侧

关键位置：

- `/home/peng/isacc_slam/reference/OVO`

当前角色：

- 提供类别定义、部分语义模块、配置和数据格式参考
- 当前在线主线**不再依赖**旧的：
  - `/home/peng/isacc_slam/reference/OVO/run_online_incremental.py`

而是改为：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/run_semantic_observer_online.py`

---

## 3. 当前运行进程拓扑

### 3.1 标准启动顺序

#### 1. Isaac Sim

```bash
cd /home/peng/isacc_slam
env -u PYTHONPATH -u AMENT_PREFIX_PATH -u COLCON_PREFIX_PATH -u CMAKE_PREFIX_PATH -u CONDA_PREFIX -u CONDA_DEFAULT_ENV -u CONDA_PROMPT_MODIFIER \
/home/peng/IsaacSim/_build/linux-x86_64/release/python.sh \
/home/peng/isacc_slam/src/onemap_semantic_mapper/scripts/isaac_turtle_stage_runner.py \
--usd_path '/home/peng/isacc learned/tutle/turtle.usd' \
--profile livo2
```

#### 2. FAST-LIVO2 + RViz

```bash
cd /home/peng/isacc_slam
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch fast_livo mapping_isaac.launch.py use_rviz:=True
```

#### 3. 在线语义观察链

```bash
cd /home/peng/isacc_slam
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch onemap_semantic_mapper ovo_async_livo2.launch.py \
  use_rviz:=False \
  launch_fast_livo:=False \
  scene_name:=your_scene \
  experiment_name:=your_experiment \
  clear_output_on_start:=True \
  resume_if_exists:=False
```

### 3.2 当前 ROS 图中的主节点

- `Isaac Sim`
  - 发布 `/robot_rgb`、`/depth`、`/camera_info`、`/livox/lidar`、`/livox/imu`
- `laserMapping` (`FAST-LIVO2`)
  - 订阅上面这些原始传感器流
  - 发布 `/cloud_registered`、`/aft_mapped_to_init`、`/path`
- `livo2_ovo_keyframe_exporter`
  - 订阅 `/robot_rgb`、`/depth`、`/camera_info`、`/aft_mapped_to_init`、`/cloud_registered`
  - 导出关键帧和 manifests
- `ovo_async_worker`
  - 轮询 run/export 目录
  - 拉起 `run_semantic_observer_online.py`
- `run_semantic_observer_online.py`
  - 读取 manifests
  - 生成 observation/object memory/snapshot
- `ovo_semantic_map_publisher`
  - 发布 `/ovo_semantic_map`
  - 发布 `/ovo_instance_labels`
- `ovo_semantic_lidar_map_publisher`
  - 订阅 `/cloud_registered`
  - 读取 `semantic_snapshot.npz`
  - 发布 `/ovo_semantic_lidar_map`
  - 发布 `/ovo_instance_labels_lidar`

### 3.3 为什么 launch 里要先杀旧 OVO 节点

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/launch/ovo_async_livo2.launch.py`

原因：

- 以前残留的 `ovo_async_worker` / publisher 会继续发旧快照
- 造成“只重启 LIVO2 就有幽灵语义图”

当前做法：

- 启动前先 `pkill`：
  - `ovo_async_worker`
  - `ovo_semantic_map_publisher`
  - `ovo_semantic_lidar_map_publisher`
  - `run_semantic_observer_online.py`
- 延迟 `1s` 再拉新节点

---

## 4. Topic 与消息合同

### 4.1 Isaac Sim 传感器输入

- `/robot_rgb`
  - `sensor_msgs/msg/Image`
- `/depth`
  - `sensor_msgs/msg/Image`
- `/camera_info`
  - `sensor_msgs/msg/CameraInfo`
- `/livox/lidar`
  - LiDAR 原始点云流
- `/livox/imu`
  - IMU 原始流

### 4.2 FAST-LIVO2 输出

- `/cloud_registered`
  - 当前连续优化后的 LiDAR 注册点云
  - 是 RViz 看起来“几何比较稳”的主图
- `/aft_mapped_to_init`
  - `nav_msgs/msg/Odometry`
  - 当前位姿主权威
- `/path`
  - `nav_msgs/msg/Path`

### 4.3 在线语义输出

- `/ovo_semantic_map`
  - 当前工作态语义点云
  - 来自 `semantic_snapshot.npz`
- `/ovo_instance_labels`
  - 当前对象标签文字
- `/ovo_semantic_lidar_map`
  - 把 `semantic_snapshot.npz` 里的语义近邻投到 `/cloud_registered` 得到的 LiDAR 语义图
- `/ovo_instance_labels_lidar`
  - LiDAR 语义图标签文字

---

## 5. 目录、文件和中间产物合同

### 5.1 Dataset scene 目录

路径：

- `/home/peng/isacc_slam/reference/OVO/data/input/Datasets/Replica/<scene_name>`

内容：

- `results/frame*.jpg`
- `results/depth*.png`
- `traj.txt`
- `frames_index.csv`
- `export_info.yaml`
- `sensor_config.yaml`
- `local_clouds/local_cloud_*.npz`

作用：

- 保留 Replica 风格数据集合同
- 兼容 OVO 旧 loader

### 5.2 Run 导出目录

路径：

- `/home/peng/isacc_slam/runs/ovo_pose_keyframes/<run_id>/export`

内容：

- `keyframe_packets.jsonl`
- `local_cloud_packets.jsonl`
- `observation_links.jsonl`
- `session.json`
- `manifest.md`
- `results/frame*.jpg`
- `results/depth*.png`
- `local_clouds/local_cloud_*.npz`

作用：

- 这是当前在线语义观察器真正依赖的稳定运行态工件目录

### 5.3 在线输出目录

路径：

- `/home/peng/isacc_slam/reference/OVO/data/output/Replica/<experiment_name>/<scene_name>`

内容：

- `semantic_snapshot.npz`
- `semantic_snapshot_summary.txt`
- `object_memory.json`
- `online_status.json`
- `observer_state.json`

作用：

- 这是在线语义观察器和发布器共享的运行态输出目录

---

## 6. 核心数据结构

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/data_types.py`

### 6.1 `SensorConfig`

字段：

- `sensor_config_id`
- `calib_version`
- `camera_model`
- `intrinsics`
- `t_lidar_cam`
- `image_size`
- `r_lidar_cam`
- `t_imu_lidar`
- `r_imu_lidar`

作用：

- 把内参、外参和图像尺寸固定成一个可持久化合同

### 6.2 `KeyframePacket`

字段：

- `keyframe_id`
- `stamp_sec`
- `t_world_body`
- `t_world_lidar`
- `t_world_cam`
- `rgb_path`
- `depth_path`
- `local_cloud_ref`
- `local_cloud_frame`
- `sensor_config_id`
- `calib_version`
- `pose_source`
- `status`
- `source_scan_ids`
- `selection_reasons`
- `pose_alignment`
- `pose_dt_sec`

作用：

- 记录关键帧图像、位姿、局部点云引用和选择原因

### 6.3 `LocalCloudPacket`

字段：

- `local_cloud_id`
- `source_scan_ids`
- `stamp_start`
- `stamp_end`
- `frame`
- `cloud_path`
- `point_count`
- `parent_submap_id`

作用：

- 记录某次关键帧使用的局部点云工件

### 6.4 `ObservationLink`

字段：

- `keyframe_id`
- `mask_id`
- `local_cloud_id`
- `point_indices`
- `semantic_label_candidates`
- `semantic_scores`
- `candidate_object_id`
- `vote_count`
- `visibility_score`
- `bbox_xyxy`
- `mask_area`

作用：

- 记录某个 2D mask 与某批 3D 点之间的映射结果

### 6.5 `ObjectMemory`

字段：

- `object_id`
- `point_support_refs`
- `centroid_world`
- `bbox_world`
- `label_votes`
- `embedding_path`
- `best_view_keyframes`
- `observation_count`
- `stability_score`
- `completeness_score`
- `dirty_flag`
- `last_seen_stamp`

作用：

- 记录某个 3D 对象当前累计得到的支持点、标签票、中心和状态

---

## 7. 一次关键帧从传感器到语义点云的完整路径

这一节只讲“单次关键帧”的完整数据流，方便后面排 bug 时直接对照。

### 7.1 传感器进入 FAST-LIVO2

1. Isaac Sim 发布：
   - `/robot_rgb`
   - `/depth`
   - `/camera_info`
   - `/livox/lidar`
   - `/livox/imu`
2. `FAST-LIVO2` 的：
   - `livox_pcl_cbk(...)`
   - `imu_cbk(...)`
   - `img_cbk(...)`
   先把数据吃进内部缓存。
3. `sync_packages(...)` 负责把 LiDAR/IMU/图像整理成当前一次处理所需的同步包。
4. `handleLIO()` 和 `handleVIO()` 更新当前状态。
5. `publish_frame_world(...)` 发布 `/cloud_registered`
6. `publish_odometry(...)` 发布 `/aft_mapped_to_init`

### 7.2 Exporter 把当前时刻冻结成一个关键帧合同

1. `/robot_rgb` 到达：
   - `Livo2OVOKeyframeExporter._image_callback`
2. `/depth` 到达：
   - `Livo2OVOKeyframeExporter._depth_callback`
3. `/aft_mapped_to_init` 到达：
   - `Livo2OVOKeyframeExporter._odom_callback`
4. `/cloud_registered` 到达：
   - `Livo2OVOKeyframeExporter._cloud_callback`
5. 图像或深度回调会继续触发：
   - `Livo2OVOKeyframeExporter._try_export_frame(image_stamp)`
6. `_try_export_frame` 内部依次调用：
   - `_find_closest` 找最近 image/depth
   - `_build_local_submap` 找当前关键帧的 local cloud
   - `_interpolate_pose` 找当前 `T_world_cam`
   - `blur_score`
   - `coverage_novelty`
7. 若质量门和触发门都通过：
   - `_save_frame(...)`
   - `_write_keyframe_packet(...)`
8. `_save_frame` 写盘：
   - scene 目录 RGB/depth/local cloud
   - run-local export 目录 RGB/depth/local cloud
   - `traj.txt`
   - `frames_index.csv`
   - `local_cloud_packets.jsonl`
9. `_write_keyframe_packet` 再追加：
   - `keyframe_packets.jsonl`

### 7.3 Worker 发现新 manifests 并拉起观察器

1. `ovo_async_worker._poll()`
2. `_resolve_export_dir()` 找最新 export 目录
3. `_build_command(...)` 组织命令：
   - `run_semantic_observer_online.py --scene-dir ... --export-dir ...`
4. `_start_process(...)` 拉起观察器子进程

### 7.4 观察器处理这个关键帧

1. `OnlineSemanticObserverRunner.process_once()`
   - `load_keyframe_packets(...)`
   - `load_local_cloud_packets(...)`
2. 找到还没处理的 `KeyframePacket`
3. 调 `_process_keyframe(packet, local_cloud)`
4. `_process_keyframe` 内部：
   - `_load_image(...)`
   - `_load_depth(...)`
   - `VisibilityProjector.project(...)`
   - `OnlineSemanticAdapter.build_mask_observations(...)`
   - `ObjectMemoryStore.point_object_ids_for_local_cloud(...)`
   - `SemanticObserver.observe(...)`
   - `ObjectMemoryStore.update(...)`
   - `append_observation_link(...)`

### 7.5 对象记忆更新与快照导出

1. `ObjectMemoryStore.update(...)`
   - 用 observation 更新当前点级归属
   - 对当前 cloud 可见但未命中的点施加负证据
   - 用 `global_voxel_index` 回写历史 cloud 附近点
   - 重建 supports
   - 重算对象
   - 清理弱点和弱对象
2. `OnlineSemanticObserverRunner._export_snapshot()`
   - 遍历所有对象
   - `_collect_object_points(...)`
   - `_voxel_downsample(...)`
   - 给对象统一上语义颜色
   - 原子写：
     - `semantic_snapshot.npz`

### 7.6 发布到 RViz

1. `OVOSemanticMapPublisher._timer_callback()`
   - 发现 `semantic_snapshot.npz` 更新
   - `_load_artifact()`
   - 发 `/ovo_semantic_map`
   - 发 `/ovo_instance_labels`
2. `OVOSemanticLidarMapPublisher._timer_callback()`
   - 发现同一份 snapshot 更新
   - `_load_artifact()`
   - 用 `_project_lidar_cloud(...)` 把语义近邻投到 `/cloud_registered`
   - 发 `/ovo_semantic_lidar_map`
   - 发 `/ovo_instance_labels_lidar`

### 7.7 这个路径为什么现在还会不稳定

问题不是只在一处，而是因为上面这条链里：

- exporter 固定的是关键帧时刻局部点云，不是 LIVO2 连续在线地图本身
- 语义观察器用的是 mask + 投影 + depth gate，不是 FAST-LIVO2 级别的 patch 质量控制
- object memory 虽然现在已经能跨历史 cloud 回写，但还没有完全做到“几何主图驱动的全局语义真值”

---

## 8. FAST-LIVO2 侧函数级架构

### 7.1 `LIVMapper` 的整体生命周期

文件：

- `/home/peng/isacc_slam/src/FAST-LIVO2/src/LIVMapper.cpp`
- `/home/peng/isacc_slam/src/FAST-LIVO2/include/LIVMapper.h`

主链：

1. `LIVMapper::LIVMapper(...)`
   - 构造主节点
2. `readParameters(...)`
   - 读 `avia_isaac.yaml` 和 `camera_pinhole.yaml`
3. `initializeComponents(...)`
   - 初始化内部 `VIOManager`、地图、状态
4. `initializeSubscribersAndPublishers(...)`
   - 创建 ROS 订阅和发布
5. `run(...)`
   - 主循环
6. 在主循环中交替执行：
   - `imu_prop_callback()`
   - `processImu()`
   - `stateEstimationAndMapping()`
   - `handleVIO()`
   - `handleLIO()`
   - `publish_*()`

### 7.2 关键输入回调

#### `standard_pcl_cbk(...)` / `livox_pcl_cbk(...)`

作用：

- 接 LiDAR 点云
- 转成内部点云缓存
- 写入 `lidar_buffer`

#### `imu_cbk(...)`

作用：

- 接 IMU
- 做基础预处理
- 写入 `imu_buffer`

#### `img_cbk(...)`

作用：

- 接图像
- 转 `cv::Mat`
- 进入视觉侧流程

### 7.3 同步与估计

#### `sync_packages(...)`

作用：

- 按时间对齐 LiDAR/IMU/图像
- 形成一次处理所需的 `LidarMeasureGroup`

#### `imu_prop_callback()`

作用：

- 做 IMU 预积分传播

#### `stateEstimationAndMapping()`

作用：

- 调度 LIO 和 VIO
- 更新状态和地图

#### `handleLIO()`

作用：

- 处理 LiDAR 主更新

#### `handleVIO()`

作用：

- 用图像对 LiDAR/IMU 状态做视觉约束更新

### 7.4 发布函数

#### `publish_frame_world(...)`

作用：

- 把当前注册后的点云发布到 `/cloud_registered`

#### `publish_odometry(...)`

作用：

- 把当前状态发布到 `/aft_mapped_to_init`

#### `publish_path(...)`

作用：

- 把累计路径发布到 `/path`

#### `current_output_stamp()`

当前重要点：

- 这部分之前曾错误地使用 wall-time
- 后来已经修成与传感器时间轴一致

---

## 8. FAST-LIVO2 为什么点云和图像结合得稳

关键文件：

- `/home/peng/isacc_slam/src/FAST-LIVO2/src/vio.cpp`
- `/home/peng/isacc_slam/src/FAST-LIVO2/src/visual_point.cpp`

当前结论：

`FAST-LIVO2` 稳，不是因为它“简单把像素投到点上”，而是因为它只让**几何和视觉都足够可信**的点参与融合。

### 8.1 `VIOManager::retrieveFromVisualSparseMap(...)`

作用：

- 从当前视觉稀疏图里检索候选视觉点
- 不是所有点都能参加视觉更新

### 8.2 `VIOManager::generateVisualMapPoints(...)`

作用：

- 生成新的视觉地图点
- 不是乱加点，而是按纹理和图像栅格筛选

### 8.3 `VIOManager::computeJacobianAndUpdateEKF(...)`

作用：

- 对通过质量门槛的点做视觉更新

### 8.4 `VisualPoint::getCloseViewObs(...)`

作用：

- 为当前点选择更合适的历史参考视角

### 8.5 `calculateNCC(...)`, `warpAffine(...)`, `getWarpMatrixAffine(...)`

作用：

- 做 patch 级一致性验证
- 这是当前语义链**还没有学到**的能力

这也是为什么：

- `FAST-LIVO2` 几何准
- 当前语义观察器却仍然容易把植物后面的墙污染成植物

因为当前语义链还只有：

- 2D mask
- 3D 点投影
- depth gate
- 对象记忆投票

没有 patch/NCC/法向质量那一层。

---

## 9. Exporter 侧详细数据流

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/livo2_ovo_keyframe_exporter.py`

### 9.1 顶层辅助函数

#### `stamp_to_seconds`

输入：

- ROS `stamp`

输出：

- `float` 秒时间戳

#### `quaternion_to_rotation_matrix`

输入：

- `x y z w`

输出：

- `3x3 rotation`

#### `rotation_matrix_to_quaternion`

输入：

- `3x3 rotation`

输出：

- `xyzw quaternion`

#### `quaternion_slerp`

输入：

- 两个四元数和插值比例

输出：

- 插值四元数

作用：

- 用于关键帧图像时间和 odom 时间不完全对齐时的姿态插值

#### `rotation_angle_deg`

作用：

- 算相邻关键帧旋转差

#### `blur_score`

作用：

- 用 Laplacian 方差评估图像清晰度

#### `coverage_novelty`

作用：

- 粗栅格统计深度覆盖率新颖性
- 用来辅助关键帧筛选

#### `pointcloud_xyz_array`

作用：

- 把 ROS `PointCloud2` 解码为 `Nx3 float32`

### 9.2 缓冲数据结构

- `BufferedImage`
- `BufferedDepth`
- `BufferedOdom`
- `BufferedCloud`
- `BufferedCloudSubmap`

这些结构只活在 exporter 内存里，用来存最近一段时间的原始输入。

### 9.3 `Livo2OVOKeyframeExporter.__init__`

主要流程：

1. `self._declare_parameters()`
2. `self._load_parameters()`
3. 初始化 image/depth/odom/cloud 缓冲区
4. 构造 scene/run/export 路径
5. 打开：
   - `traj.txt`
   - `frames_index.csv`
   - `trajectory_raw.jsonl`
   - `aligned_frames.jsonl`
   - `accepted_frames.jsonl`
   - `keyframes.jsonl`
6. 写：
   - metadata
   - contract check
   - manifest
   - export session
7. 创建订阅：
   - `/robot_rgb`
   - `/depth`
   - `/camera_info`
   - `/aft_mapped_to_init`
   - `/cloud_registered`

### 9.4 参数加载 `_declare_parameters` / `_load_parameters`

这一层定义了：

- topic 名
- 外参：
  - `Rcl`
  - `Pcl`
  - `extrinsic_T`
  - `extrinsic_R`
- 相机内参
- local cloud 抓取策略
- 关键帧策略

当前重要默认值：

- `export.local_cloud_window_sec = 0.0`
- `export.local_cloud_min_scans = 1`
- `export.local_cloud_max_scans = 1`

也就是：

**当前默认已经回退成单帧 local cloud，不再默认用多帧局部子图。**

### 9.5 回调函数

#### `_image_callback`

输入：

- `/robot_rgb`

动作：

- 转 `RGB numpy`
- 写入 `_image_buffer`
- 触发 `_try_export_frame(stamp)`

#### `_depth_callback`

输入：

- `/depth`

动作：

- 解码 depth，换算到米
- 写入 `_depth_buffer`
- 触发 `_try_export_frame(stamp)`

#### `_camera_info_callback`

输入：

- `/camera_info`

动作：

- 记录图像尺寸
- 如果允许，可以覆盖内参
- 当前默认 `override_intrinsics_from_camera_info = False`

#### `_odom_callback`

输入：

- `/aft_mapped_to_init`

动作：

- 提取 rotation + translation + quaternion
- 写入 `_odom_buffer`

#### `_cloud_callback`

输入：

- `/cloud_registered`

动作：

- 解码 `PointCloud2`
- 生成 `BufferedCloud`
- 写入 `_cloud_buffer`

### 9.6 `_interpolate_pose`

输入：

- 某一帧图像时间戳

过程：

1. 在 `_odom_buffer` 中找前后两个最近 odom
2. 如果完全命中，直接用该 pose
3. 如果在 `sync_slop_sec` 范围内，做平移线性插值 + 四元数 slerp
4. 调 `_camera_to_world_matrix(...)`

输出：

- `c2w`
- `pose_dt`
- `match_type`

### 9.7 `_camera_to_world_matrix` 和 `_transform_camera_points_to_world`

作用：

- 把 `FAST-LIVO2` 的 body/imu 权威位姿，通过 `Rcl/Pcl`、`Rli/Pli` 变成 `T_world_cam`

这一步非常关键，因为：

- `FAST-LIVO2` 的权威位姿不是相机位姿
- OVO 侧需要 `T_world_cam`

### 9.8 `_build_local_submap`

当前默认行为：

- 因为 `window_sec=0, min_scans=1, max_scans=1`
- 所以默认退化成：**离关键帧最近的一帧 `/cloud_registered`**

保留但默认关闭的能力：

- 当参数显式放开时，可以拼一个短时间窗局部子图

当前结论：

- 这条“多帧局部子图”实验已经证明在当前语义观察器里会放大背景污染
- 所以默认关闭

### 9.9 `_try_export_frame`

这是 exporter 的核心函数。

输入：

- 某一时刻 `image_stamp`

流程：

1. 找最接近的 image/depth
2. 找 local cloud
3. 用 `_interpolate_pose` 对齐位姿
4. 算质量指标：
   - `depth_valid_ratio`
   - `blur_score`
   - `coverage_novelty`
5. 先写 `aligned_frames.jsonl`
6. 判断 quality reject：
   - 无 pose
   - 非单调
   - depth 比例太低
   - 图像太糊
7. 判断 trigger：
   - translation
   - rotation
   - coverage
   - time
8. 若通过：
   - 调 `_save_frame`
   - 调 `_write_keyframe_packet`
   - 写 `accepted_frames.jsonl`
   - 写 `keyframes.jsonl`

### 9.10 `_save_frame`

输入：

- `image_rgb`
- `depth_m`
- `c2w`
- `image_stamp`
- `depth_stamp`
- `pose_stamp`
- `local_submap`

输出：

- 写 scene 目录：
  - `results/frame*.jpg`
  - `results/depth*.png`
  - `local_clouds/local_cloud_*.npz`
  - `traj.txt`
  - `frames_index.csv`
- 写 run-local export 目录镜像：
  - `export/results/frame*.jpg`
  - `export/results/depth*.png`
  - `export/local_clouds/local_cloud_*.npz`
- 追加：
  - `local_cloud_packets.jsonl`

### 9.11 `_write_keyframe_packet`

作用：

- 生成 `KeyframePacket`
- 把：
  - `T_world_body`
  - `T_world_lidar`
  - `T_world_cam`
  - `local_cloud_ref`
  - `selection_reasons`
  - `pose_alignment`
  - `pose_dt_sec`
  等信息写进 `keyframe_packets.jsonl`

这一步是 observer_online 的直接上游合同。

---

## 10. Observer Online 侧详细数据流

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/observer_online.py`

### 10.1 `parse_args`

定义在线观察器运行参数：

- scene/export/output 目录
- OVO 配置
- 轮询周期
- 最小关键帧数
- 处理频率
- depth tolerance
- snapshot 参数
- mask erosion
- object merge 半径

### 10.2 `OnlineSemanticAdapter`

职责：

- 包装 `MaskGenerator` 和 `CLIPGenerator`
- 给一张 RGB 图输出一组 `MaskObservation`

#### `_build_text_embeddings`

输入：

- 类别名列表
- prompt templates

输出：

- 每个类别的 CLIP 文本 embedding

#### `build_mask_observations`

输入：

- `image_rgb`
- `frame_id`

流程：

1. `SAM` 生成 mask
2. `CLIP` 生成每个 mask 的视觉 embedding
3. 与文本 embedding 相似度匹配
4. 给每个 mask 生成：
   - 二值 mask
   - bbox
   - top-k 类别候选
   - top-k 分数

输出：

- `list[MaskObservation]`

### 10.3 `OnlineSemanticObserverRunner`

职责：

- 整个在线观察主循环

#### `__init__`

主要做：

1. 解析目录
2. 建 `status/state/object_memory/snapshot` 路径
3. 视需要清空旧状态
4. 读 `observer_state.json`
5. 读 OVO config
6. 读类别表
7. 读 `sensor_config.yaml`
8. 创建：
   - `VisibilityProjector`
   - `SemanticObserver`
   - `ObjectMemoryStore`
   - `OnlineSemanticAdapter`

#### `run`

无限循环：

- 调 `process_once()`
- 若没新东西，sleep

#### `process_once`

这是在线主调度器。

流程：

1. 读：
   - `keyframe_packets.jsonl`
   - `local_cloud_packets.jsonl`
2. 若关键帧数不够：
   - 写 `online_status.json`
   - 返回
3. 取没处理过的新 `KeyframePacket`
4. 对每个 packet：
   - 找对应 `LocalCloudPacket`
   - 调 `_process_keyframe`
5. 本轮若处理了新 keyframe：
   - 保存 `object_memory.json`
   - 保存 `observer_state.json`
6. 如果达到 snapshot 刷新条件：
   - 调 `_export_snapshot`
7. 最后写 `online_status.json`

#### `_process_keyframe`

这是当前语义主逻辑。

输入：

- `KeyframePacket`
- `LocalCloudPacket`

流程：

1. `_load_image(packet.rgb_path)`
2. `_load_depth(packet.depth_path)`
3. `self.projector.project(packet, local_cloud, sensor_config, depth_m)`
   - 得到当前 keyframe 下可见 LiDAR 点
4. `self.semantic_adapter.build_mask_observations(image_rgb, keyframe_id)`
   - 得到当前 RGB 的语义 mask 候选
5. `self.object_memory.point_object_ids_for_local_cloud(...)`
   - 查询当前 local cloud 的点已有对象归属
6. `self.observer.observe(...)`
   - 把 mask 和可见点结合成 `ObservationLink`
7. `self.object_memory.update(...)`
   - 更新对象记忆
8. 把每条 `ObservationLink` 追加到：
   - `observation_links.jsonl`

#### `_export_snapshot`

作用：

- 从 `self.object_memory.objects.values()` 里遍历每个对象
- 调 `_collect_object_points(obj.point_support_refs)`
- 体素降采样
- 根据对象当前 top label 给该对象整批点统一上色
- 拼成：
  - `xyz`
  - `rgb`
  - `instance_id`
  - `class_id`
  - `instance_centers`
  - `instance_labels`
  - `instance_point_counts`
  - `instance_view_counts`
- 原子写到：
  - `semantic_snapshot.npz`

关键点：

- 当前 snapshot 还是**对象支持点拼接后的 working map**
- 不是 `FAST-LIVO2` 连续几何主图本身

---

## 11. 投影层与 2D mask 观察层

### 11.1 `VisibilityProjector`

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/visibility_projector.py`

#### `load_local_cloud`

输入：

- `LocalCloudPacket`

输出：

- `xyz Nx3`

#### `project`

输入：

- `KeyframePacket`
- `LocalCloudPacket`
- `SensorConfig`
- `depth_m`

流程：

1. 读 local cloud
2. `t_world_cam -> w2c`
3. 把 local cloud 从 world 变到当前 camera 坐标系
4. 用 `fx fy cx cy` 投影到图像
5. 去掉：
   - 相机后方点
   - 出图像边界点
   - 同像素深度更远的点
6. 若有 depth：
   - 做深度一致性过滤
   - 当前默认容差 `0.03m`

输出：

- `VisibleProjection`
  - `visible_point_indices`
  - `projected_uv`
  - `projected_depth`
  - `visibility_score`

### 11.2 `SemanticObserver`

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/semantic_observer.py`

#### `_normalize_mask`

作用：

- 统一 mask 输入格式
- 计算 bbox
- 做自适应 erosion

当前重要点：

- 小 mask 不再强制固定 `2px` 腐蚀
- 因为植物、椅子腿这类细目标会被直接吃掉

#### `_effective_min_hit_points`

作用：

- 小目标降低最少命中点阈值

#### `observe`

输入：

- `keyframe_id`
- `local_cloud_id`
- `projection`
- `masks`
- `existing_point_object_ids`

流程：

1. 遍历每个 mask
2. 检查 mask 面积
3. 用 `mask.binary_mask[uv]` 找命中点
4. 对小目标自适应降低命中阈值
5. 如果给了 `existing_point_object_ids`
   - 用已有 3D 点实例做多数投票
   - 得到 `candidate_object_id`
6. 生成 `ObservationLink`

输出：

- `list[ObservationLink]`

---

## 12. 对象记忆层详细逻辑

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/object_memory.py`

这是当前项目里最关键、也最容易出问题的地方。

### 12.1 当前对象记忆的核心状态

- `objects`
  - 当前对象集合
- `point_assignments`
  - 每个 `local_cloud_id` 下，每个点当前属于哪个对象、分数多少
- `local_cloud_paths`
  - local cloud 文件路径索引
- `local_cloud_xyz_cache`
  - local cloud 点云缓存
- `global_voxel_index`
  - 全局体素索引

### 12.2 `update`

这是当前语义动态更新的总入口。

输入：

- `observations`
- `keyframe_stamp_sec`
- `keyframe_id`
- `local_cloud`
- `visible_point_indices`

流程：

1. 读当前 `local_cloud` 的 xyz
2. 准备当前 cloud 的 `local_states`
3. 重建 `global_voxel_index`
4. 遍历 observations：
   - 过滤太小观测
   - 根据 centroid + label 兼容性找候选对象 `_resolve_object_id`
   - 若没有则 `_ensure_object_id`
5. 对 observation 命中的每个点：
   - `_get_or_create_point_state`
   - `_apply_positive_evidence`
   - `_reconcile_point_assignment`
6. 对 observation 没命中、但本次可见的点：
   - `_apply_negative_evidence`
   - `_reconcile_point_assignment`
7. 对历史邻居点：
   - `_propagate_to_historical_neighbors`
   - 这是本轮新增的“跨历史 cloud 回写”
8. 重建 support：
   - `_refresh_supports_for_local_cloud`
   - `_refresh_all_supports`
9. 重算对象：
   - `_recompute_objects`
10. 清理：
   - `_prune_point_assignments`
   - `_prune_objects`
11. 重建：
   - `_rebuild_global_voxel_index`

### 12.3 点级可逆逻辑

#### `_apply_positive_evidence`

作用：

- 给目标对象加分
- 同时给其它对象轻微减分

#### `_apply_negative_evidence`

作用：

- 当前可见但没有再命中某对象的点，会给旧对象减分

#### `_reconcile_point_assignment`

作用：

- 根据各对象分数、margin、keep threshold 决定：
  - 保持旧对象
  - 切到新对象
  - 变成未分配

这一步实现了：

- 点级可重分配
- 不是简单 append-only

### 12.4 历史点回写

#### `_rebuild_global_voxel_index`

作用：

- 把所有当前已分配点按空间体素建索引

#### `_propagate_to_historical_neighbors`

作用：

- 对当前 observation 命中的点，去找附近历史 local cloud 中空间邻近的点
- 如果这些历史点原来属于别的对象，可以：
  - 给目标对象加正证据
  - 给旧对象减负证据
  - 再次 `_reconcile_point_assignment`

这一步是当前刚补上的“跨历史 cloud 动态清洗”。

### 12.5 对象级更新

#### `_labels_compatible`

作用：

- 防止仅凭质心近就把不同语义对象乱并

#### `_apply_label_evidence`

作用：

- 对象标签票带衰减更新，不再永远只增不减

#### `_refresh_supports_for_local_cloud` / `_refresh_all_supports`

作用：

- 根据点级最新归属重建每个对象的 `point_support_refs`

#### `_prune_objects`

作用：

- 删除没有支持点或过于弱小的对象

---

## 13. Worker、发布器和 Launch

### 13.1 `OVOAsyncWorker`

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_async_worker.py`

职责：

- 查找当前 scene 对应的最新 export 目录
- 校验 `session.json`
- 构造命令行
- 拉起 `run_semantic_observer_online.py`

关键逻辑：

- `_resolve_export_dir`
  - 找 run/export
- `_session_is_acceptable`
  - 如果 `resume_if_exists=False`
  - 只接受本次启动之后新建的 export 会话
- `_build_command`
  - 把 launch 参数拼成 observer 子进程命令
- `_poll`
  - 启动、监控和重启 observer 子进程

### 13.2 `OVOSemanticMapPublisher`

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_map_publisher.py`

职责：

- 读取 `semantic_snapshot.npz`
- 直接发布语义着色点云
- 发布文字标签

关键流程：

1. `_timer_callback`
   - 轮询 artifact 文件修改时间
2. `_load_artifact`
   - 读 `xyz/rgb/instance_id/class_id`
   - 构造彩色 `PointCloud2`
   - 构造 `MarkerArray`

注意：

- `/ovo_semantic_map` 代表的是 **snapshot working map**
- 不是 `FAST-LIVO2` 连续几何主图

### 13.3 `OVOSemanticLidarMapPublisher`

文件：

- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/ovo_semantic_lidar_map_publisher.py`

职责：

- 订阅 `/cloud_registered`
- 读取 `semantic_snapshot.npz`
- 用 `cKDTree` 最近邻把 snapshot 语义投到当前 LiDAR 点云

关键流程：

1. `_load_artifact`
   - 读 snapshot
   - 建 `cKDTree`
2. `_cloud_callback`
   - 收到最新 `/cloud_registered`
3. `_project_lidar_cloud`
   - 对当前 LiDAR 点做 kNN + 半径限制
   - 选择最近语义点的实例与类别
   - 生成 `/ovo_semantic_lidar_map`

注意：

- 这一步改善的是显示方式
- 不是从根上修正历史语义状态

### 13.4 `ovo_async_livo2.launch.py`

职责：

- 统一拉起：
  - 可选 FAST-LIVO2
  - exporter
  - worker
  - semantic publisher
  - lidar semantic publisher

当前关键点：

- `launch_fast_livo` 默认 `False`
  - 避免你单独起 `FAST-LIVO2` 后，语义 launch 又重复起一套
- `launch_exporter` 可开关
- `artifact_path` 动态跟随 scene/experiment
- 启动前先 `cleanup_old_ovo`

---

## 14. 当前外参、时间轴和数据对齐

### 14.1 当前外参

文档：

- `/home/peng/isacc_slam/docs/current_isaac_sensor_extrinsics_20260329_office.md`

当前测得：

- `imu -> lidar = [0.0, 0.0, 0.790440008]`
- `lidar -> camera = [0.0, 0.0, 0.0]`

同步文件：

- `/home/peng/isacc_slam/src/FAST-LIVO2/config/avia_isaac.yaml`
- `/home/peng/isacc_slam/src/onemap_semantic_mapper/onemap_semantic_mapper/livo2_ovo_keyframe_exporter.py`

### 14.2 当前时间轴

当前结论：

- 之前 wall-time / sim-time 混乱问题已经修到比早期稳定很多
- exporter 与 `/aft_mapped_to_init` 的对齐均值已经降到毫秒级
- 但语义误差现在更主要来自：
  - 观察器几何载体
  - 稀疏点和背景点数不平衡
  - 历史污染对象记忆

---

## 15. 当前问题为什么仍然存在

虽然我们已经做了：

- 更严格的 depth gate
- 自适应 mask erosion
- `existing_point_object_ids`
- 点级可逆归属
- 跨历史 cloud 的 global voxel 回写

但语义仍然不稳定，核心原因仍然有这些：

### 15.1 几何底座不是同一套东西

- `FAST-LIVO2` RViz 上你看到的是连续在线几何 `/cloud_registered`
- 语义观察器用的是关键帧冻结的 `local_cloud_*.npz`

这两者天然就不是完全同层精度。

### 15.2 语义赋值不是逐像素逐点真配对

当前语义链是：

- 先有稀疏 LiDAR 点
- 再看哪些点投到 2D mask 里

所以对植物这种细目标：

- RGB 里很容易分出来
- 但 3D LiDAR 命中点太少
- 后墙点更多
- 一旦 mask 边缘漏一点，背景就容易在 3D 里占主导

### 15.3 关键帧质量问题

不是“关键帧太少”这么简单，而是：

- 如果主要靠 rotation 触发
- 视差不足
- 前景植物和后墙不容易分离

### 15.4 当前 `/ovo_semantic_lidar_map` 只是投影显示

它不是“LIVO2 连续地图本身已经有语义状态”。

它只是：

- 读 snapshot
- 再投到当前 `/cloud_registered`

所以它改善显示，不等于历史语义状态已经干净。

### 15.5 当前观察器还没有学到 FAST-LIVO2 的 patch 级质量控制

`FAST-LIVO2` 稳，是因为它在视觉点进入系统前有：

- 视角条件
- patch warp
- NCC
- 光度误差门
- 纹理筛选

当前语义链还只有：

- mask
- 点投影
- depth gate
- 对象记忆

这也是当前误差仍然大的根本差距。

---

## 16. 本轮阶段性结论

当前系统已经从最早的“OVO 直接自己建 working geometry”收敛到了更合理的结构：

- `FAST-LIVO2` 做几何和位姿主权威
- exporter 导出关键帧合同
- observer 做 2D 语义到 3D 点的增量观察
- object memory 做对象记忆
- publishers 把 snapshot 和 lidar-projected semantic map 发到 RViz

已经完成的重要改造：

- 时间轴比早期稳定很多
- 幽灵语义图问题基本定位清楚
- 对象记忆不再是完全 append-only
- 已经有点级可逆归属
- 已经有跨历史 cloud 的 global voxel 回写

但当前仍未彻底解决的问题：

- 植物/细目标对后墙污染
- 旋转场景下的语义大面积误投
- working map 与 geometry authority 不一致
- 标签和点支持虽然能更新，但仍不够“像论文那样干净”

---

## 17. 当前最值得继续做的方向

当前最值得继续推进的方向，不是再盲目加关键帧数量，而是：

1. 继续提高“有效关键帧”的平移视差质量
2. 给语义观察层补更多 `FAST-LIVO2` 风格的点级质量门
3. 让 `/ovo_semantic_lidar_map` 逐步从“显示投影”升级到“真正依附 LIVO2 连续几何的语义状态”
4. 让 `final_consolidation` 承担最终干净地图输出，而不是把在线 working map 当最终成品

---

## 18. 当前相关文档

- `/home/peng/isacc_slam/CURRENT_FAST_LIVO2_OVO_ARCHITECTURE_20260329.md`
- `/home/peng/isacc_slam/LIVO2_OVO_PAPER_STYLE_SEMANTIC_PLAN.md`
- `/home/peng/isacc_slam/FAST_LIVO2_OVO_语义观察器改造方案.md`
- `/home/peng/isacc_slam/docs/current_isaac_sensor_extrinsics_20260329_office.md`

本文档是上面几份文档的“现状细化版”，重点补了：

- 目录合同
- 函数级输入输出
- 每个核心函数做什么
- 数据是如何在模块之间流动的
