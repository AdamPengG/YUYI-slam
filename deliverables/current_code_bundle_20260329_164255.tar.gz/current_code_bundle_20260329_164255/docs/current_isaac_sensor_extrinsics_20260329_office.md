# Current Isaac Sensor Extrinsics (Office Scene)

Asset:
- `/home/peng/isacc learned/tutle/turtle.usd`

Measured from Isaac headless on 2026-03-29 after raising the robot LiDAR in the office asset:
- robot lidar prim: `/World/turtlebot3_burger_ROS/base_scan/Lidar`
- robot imu prim: `/World/turtlebot3_burger_ROS/base_link/imu_link/Imu_Sensor`
- robot camera prim: `/World/turtlebot3_burger_ROS/base_scan/Camera1`

World transforms:
- `lidar world t = [1.178577388, -2.947999111, 0.876008308]`
- `imu world t = [1.178577388, -2.947999111, 0.085568300]`
- `camera world t = [1.178577388, -2.947999111, 0.876008308]`
- `camera world R = [[0.0, -1.0, 0.0], [0.0, 0.0, 1.0], [-1.0, -0.0, 0.0]]`

Relative transforms from USD truth:
- `cam_from_lidar t = [0.0, 0.0, 0.0]`
- `cam_from_imu t = [0.0, 0.0, 0.790440008]`
- `lidar_from_imu t = [0.0, 0.0, 0.790440008]`

FAST-LIVO2 / exporter convention used in this repo:
- `Rcl = [0.0, -1.0, 0.0, 0.0, 0.0, -1.0, 1.0, 0.0, 0.0]`
- `Pcl = [0.0, 0.0, 0.0]`
- `extrinsic_T = [0.0, 0.0, 0.790440008]`
- `extrinsic_R = Identity`

Notes:
- The office scene also contains environment cameras like `/World/office/Camera`, but they are not part of the robot sensor chain.
- The robot LiDAR is now co-located with `Camera1` in translation, so `Pcl` becomes zero while `Rcl` stays unchanged under the repo's camera-axis convention.
