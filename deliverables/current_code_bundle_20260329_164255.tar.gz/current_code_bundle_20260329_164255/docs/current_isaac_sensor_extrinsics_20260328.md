# Current Isaac Sensor Extrinsics

Asset:
- `/home/peng/isacc learned/tutle/turtle.usd`

Measured from Isaac headless on 2026-03-28:
- `cam_from_lidar t = [0.001662359, -0.000000329, 0.619520000]`
- `cam_from_lidar R = [[0.0, 0.0, -1.0], [-1.0, 0.0, -0.0], [0.0, 1.0, 0.0]]`
- `cam_from_imu t = [0.001662359, -0.000000329, 0.723520008]`
- `cam_from_imu R = [[0.0, 0.0, -1.0], [-1.0, 0.0, -0.0], [0.0, 1.0, 0.0]]`

FAST-LIVO2 / exporter convention used in this repo:
- `Rcl = [0.0, -1.0, 0.0, 0.0, 0.0, -1.0, 1.0, 0.0, 0.0]`
- `Pcl = [-0.000000329, 0.619520000, -0.001662359]`
- `extrinsic_T = [0.0, 0.0, 0.104]`
- `extrinsic_R = Identity`

Notes:
- The current raised-camera asset changes only the lidar-to-camera translation relative to the old baseline.
- The effective camera height above IMU is `0.723520008 m`.
- The effective camera height above lidar is `0.619520000 m`.
