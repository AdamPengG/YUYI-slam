from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .data_types import LocalCloudPacket, ObjectMemory, ObservationLink


@dataclass
class ObjectMemoryUpdateResult:
    updated_object_ids: list[str]
    created_object_ids: list[str]
    ignored_observations: int


class ObjectMemoryStore:
    def __init__(
        self,
        min_points_per_observation: int = 12,
        min_mask_area: int = 64,
        max_best_views: int = 5,
        merge_centroid_radius_m: float = 0.75,
    ) -> None:
        self.min_points_per_observation = min_points_per_observation
        self.min_mask_area = min_mask_area
        self.max_best_views = max_best_views
        self.merge_centroid_radius_m = merge_centroid_radius_m
        self.point_score_increment = 1.0
        self.point_score_decrement = 0.75
        self.point_keep_threshold = 0.60
        self.point_reassign_margin = 0.20
        self.point_stale_time_sec = 60.0
        self.label_vote_decay = 0.97
        self.spatial_voxel_size_m = 0.12
        self.cross_cloud_reassign_radius_m = 0.18
        self.cross_cloud_positive_weight = 0.60
        self.cross_cloud_negative_weight = 0.90
        self.max_cross_cloud_refs_per_point = 24
        self.objects: dict[str, ObjectMemory] = {}
        self.point_assignments: dict[str, dict[int, dict[str, object]]] = {}
        self.local_cloud_paths: dict[str, str] = {}
        self.local_cloud_xyz_cache: dict[str, np.ndarray] = {}
        self.global_voxel_index: dict[tuple[int, int, int], list[tuple[str, int]]] = {}
        self._next_object_id = 0

    def update(
        self,
        observations: list[ObservationLink],
        keyframe_stamp_sec: float,
        keyframe_id: int,
        local_cloud: LocalCloudPacket,
        visible_point_indices: list[int] | np.ndarray | None = None,
    ) -> ObjectMemoryUpdateResult:
        updated: list[str] = []
        created: list[str] = []
        ignored = 0
        xyz = self._load_xyz(local_cloud)
        self.local_cloud_paths[local_cloud.local_cloud_id] = str(local_cloud.cloud_path)
        local_states = self.point_assignments.setdefault(local_cloud.local_cloud_id, {})
        affected_object_ids: set[str] = set()
        visible_points = self._normalize_visible_points(visible_point_indices, xyz.shape[0])
        effective_observations: list[tuple[ObservationLink, dict[str, float]]] = []
        self._rebuild_global_voxel_index()

        for obs in observations:
            min_points_required = self._effective_min_points_per_observation(obs.mask_area, obs.bbox_xyxy)
            if len(obs.point_indices) < min_points_required or obs.mask_area < self.min_mask_area:
                ignored += 1
                continue

            support_xyz = xyz[np.asarray(obs.point_indices, dtype=np.int32)]
            centroid = support_xyz.mean(axis=0).astype(np.float32)
            bbox_min = support_xyz.min(axis=0).astype(np.float32)
            bbox_max = support_xyz.max(axis=0).astype(np.float32)

            object_id = self._resolve_object_id(obs, centroid)
            label_votes = self._votes_from_observation(obs)
            object_id, was_created = self._ensure_object_id(
                object_id=object_id,
                centroid=centroid,
                bbox_min=bbox_min,
                bbox_max=bbox_max,
                keyframe_stamp_sec=keyframe_stamp_sec,
                keyframe_id=keyframe_id,
                label_votes=label_votes,
            )
            obs.candidate_object_id = object_id
            if was_created:
                created.append(object_id)
            effective_observations.append((obs, label_votes))
            affected_object_ids.add(object_id)

        observed_point_indices: set[int] = set()
        for obs, _label_votes in effective_observations:
            target_object_id = str(obs.candidate_object_id)
            if target_object_id not in self.objects:
                continue
            for point_index in obs.point_indices:
                if point_index < 0 or point_index >= xyz.shape[0]:
                    continue
                observed_point_indices.add(int(point_index))
                state = self._get_or_create_point_state(local_states, int(point_index), keyframe_stamp_sec)
                previous_object_id = state.get("current_object_id")
                self._apply_positive_evidence(state, target_object_id, self.point_score_increment)
                new_object_id = self._reconcile_point_assignment(state)
                state["last_seen_stamp"] = float(keyframe_stamp_sec)
                if previous_object_id and previous_object_id != new_object_id:
                    affected_object_ids.add(str(previous_object_id))
                if new_object_id:
                    affected_object_ids.add(str(new_object_id))

            obj = self.objects[target_object_id]
            obj.observation_count += 1
            obj.last_seen_stamp = float(keyframe_stamp_sec)
            obj.best_view_keyframes = self._update_best_views(obj.best_view_keyframes, keyframe_id)
            self._apply_label_evidence(obj, label_votes)
            obj.dirty_flag = True
            updated.append(target_object_id)
            self._propagate_to_historical_neighbors(
                target_object_id=target_object_id,
                source_local_cloud_id=local_cloud.local_cloud_id,
                source_xyz=xyz,
                observed_point_indices=obs.point_indices,
                stamp_sec=keyframe_stamp_sec,
                affected_object_ids=affected_object_ids,
            )

        for point_index in sorted(visible_points - observed_point_indices):
            state = local_states.get(int(point_index))
            if state is None:
                continue
            previous_object_id = state.get("current_object_id")
            if not previous_object_id:
                continue
            self._apply_negative_evidence(state, str(previous_object_id), self.point_score_decrement * 0.5)
            new_object_id = self._reconcile_point_assignment(state)
            state["last_seen_stamp"] = float(keyframe_stamp_sec)
            affected_object_ids.add(str(previous_object_id))
            if new_object_id:
                affected_object_ids.add(str(new_object_id))

        self._refresh_supports_for_local_cloud(local_cloud.local_cloud_id)
        self._recompute_objects(affected_object_ids)
        self._prune_point_assignments(keyframe_stamp_sec)
        self._refresh_all_supports()
        self._recompute_objects(set(self.objects.keys()))
        self._prune_objects()
        self._rebuild_global_voxel_index()

        return ObjectMemoryUpdateResult(updated, created, ignored)

    def to_dict(self) -> dict[str, dict]:
        return {
            "objects": {object_id: obj.to_dict() for object_id, obj in self.objects.items()},
            "local_cloud_paths": dict(self.local_cloud_paths),
            "point_assignments": {
                local_cloud_id: {
                    str(point_index): {
                        "current_object_id": payload.get("current_object_id"),
                        "current_score": float(payload.get("current_score", 0.0)),
                        "object_scores": {
                            str(object_id): float(score)
                            for object_id, score in dict(payload.get("object_scores", {})).items()
                            if float(score) > 1e-6
                        },
                        "last_seen_stamp": float(payload.get("last_seen_stamp", 0.0)),
                    }
                    for point_index, payload in point_map.items()
                }
                for local_cloud_id, point_map in self.point_assignments.items()
            },
        }

    @classmethod
    def from_dict(cls, payload: dict[str, dict]) -> "ObjectMemoryStore":
        store = cls()
        object_payloads = payload.get("objects", payload)
        for object_id, object_payload in object_payloads.items():
            store.objects[str(object_id)] = ObjectMemory.from_dict(object_payload)
        store.local_cloud_paths = {
            str(local_cloud_id): str(cloud_path)
            for local_cloud_id, cloud_path in payload.get("local_cloud_paths", {}).items()
        }
        point_payloads = payload.get("point_assignments", {})
        for local_cloud_id, point_map in point_payloads.items():
            local_states: dict[int, dict[str, object]] = {}
            for point_index, state_payload in point_map.items():
                local_states[int(point_index)] = {
                    "current_object_id": None
                    if state_payload.get("current_object_id") is None
                    else str(state_payload["current_object_id"]),
                    "current_score": float(state_payload.get("current_score", 0.0)),
                    "object_scores": {
                        str(object_id): float(score)
                        for object_id, score in state_payload.get("object_scores", {}).items()
                    },
                    "last_seen_stamp": float(state_payload.get("last_seen_stamp", 0.0)),
                }
            store.point_assignments[str(local_cloud_id)] = local_states
        if store.objects:
            max_numeric = max(int(obj_id.split("_")[-1]) for obj_id in store.objects)
            store._next_object_id = max_numeric + 1
        return store

    def _resolve_object_id(self, observation: ObservationLink, centroid: np.ndarray) -> str | None:
        if observation.candidate_object_id is not None and observation.candidate_object_id in self.objects:
            return observation.candidate_object_id

        best_id = None
        best_dist = None
        for object_id, obj in self.objects.items():
            if not self._labels_compatible(observation, obj):
                continue
            dist = float(np.linalg.norm(np.asarray(obj.centroid_world, dtype=np.float32) - centroid))
            if dist <= self.merge_centroid_radius_m and (best_dist is None or dist < best_dist):
                best_id = object_id
                best_dist = dist
        return best_id

    def point_object_ids_for_local_cloud(self, local_cloud_id: str, point_count: int) -> np.ndarray:
        output = np.empty((max(int(point_count), 0),), dtype=object)
        output[:] = None
        local_states = self.point_assignments.get(local_cloud_id, {})
        for point_index, state in local_states.items():
            if point_index < 0 or point_index >= point_count:
                continue
            object_id = state.get("current_object_id")
            if object_id:
                output[point_index] = str(object_id)
        return output

    def _create_object_id(self) -> str:
        object_id = f"obj_{self._next_object_id:05d}"
        self._next_object_id += 1
        return object_id

    def _ensure_object_id(
        self,
        object_id: str | None,
        centroid: np.ndarray,
        bbox_min: np.ndarray,
        bbox_max: np.ndarray,
        keyframe_stamp_sec: float,
        keyframe_id: int,
        label_votes: dict[str, float],
    ) -> tuple[str, bool]:
        if object_id is not None and object_id in self.objects:
            return object_id, False
        object_id = self._create_object_id()
        self.objects[object_id] = ObjectMemory(
            object_id=object_id,
            point_support_refs=[],
            centroid_world=[float(v) for v in centroid.tolist()],
            bbox_world=[float(v) for v in bbox_min.tolist() + bbox_max.tolist()],
            label_votes=dict(label_votes),
            embedding_path=None,
            best_view_keyframes=[int(keyframe_id)],
            observation_count=0,
            stability_score=1.0 if label_votes else 0.0,
            completeness_score=0.0,
            dirty_flag=True,
            last_seen_stamp=float(keyframe_stamp_sec),
        )
        return object_id, True

    def _votes_from_observation(self, observation: ObservationLink) -> dict[str, float]:
        if observation.semantic_label_candidates and observation.semantic_scores:
            return {
                str(label): float(score)
                for label, score in zip(observation.semantic_label_candidates, observation.semantic_scores)
            }
        if observation.semantic_label_candidates:
            weight = 1.0 / max(len(observation.semantic_label_candidates), 1)
            return {str(label): weight for label in observation.semantic_label_candidates}
        return {}

    def _load_xyz(self, local_cloud: LocalCloudPacket) -> np.ndarray:
        cached = self.local_cloud_xyz_cache.get(local_cloud.local_cloud_id)
        if cached is not None:
            return cached
        data = np.load(Path(local_cloud.cloud_path))
        xyz = np.asarray(data["xyz"], dtype=np.float32)
        self.local_cloud_xyz_cache[local_cloud.local_cloud_id] = xyz
        return xyz

    def _running_average(self, current: list[float], new_value: list[float], count: int) -> list[float]:
        if count <= 1:
            return [float(v) for v in new_value]
        alpha = 1.0 / float(count)
        return [float((1.0 - alpha) * c + alpha * n) for c, n in zip(current, new_value)]

    def _merge_bbox(self, current_bbox: list[float], bbox_min: np.ndarray, bbox_max: np.ndarray) -> list[float]:
        current_min = np.asarray(current_bbox[:3], dtype=np.float32)
        current_max = np.asarray(current_bbox[3:], dtype=np.float32)
        merged_min = np.minimum(current_min, bbox_min)
        merged_max = np.maximum(current_max, bbox_max)
        return [float(v) for v in merged_min.tolist() + merged_max.tolist()]

    def _update_best_views(self, existing: list[int], keyframe_id: int) -> list[int]:
        out = [int(v) for v in existing if int(v) != int(keyframe_id)]
        out.insert(0, int(keyframe_id))
        return out[: self.max_best_views]

    def _compute_stability(self, obj: ObjectMemory) -> float:
        if not obj.label_votes:
            return 0.0
        total = float(sum(obj.label_votes.values()))
        best = float(max(obj.label_votes.values()))
        if total <= 1e-6:
            return 0.0
        return best / total

    def _effective_min_points_per_observation(self, mask_area: int, bbox_xyxy: list[int]) -> int:
        bbox_w = max(int(bbox_xyxy[2]) - int(bbox_xyxy[0]), 0)
        bbox_h = max(int(bbox_xyxy[3]) - int(bbox_xyxy[1]), 0)
        min_side = min(bbox_w, bbox_h)
        if mask_area < max(self.min_mask_area * 3, 256) or min_side < 18:
            return max(8, min(self.min_points_per_observation, 8))
        if mask_area < max(self.min_mask_area * 8, 768) or min_side < 36:
            return max(8, min(self.min_points_per_observation, 10))
        return self.min_points_per_observation

    def _labels_compatible(self, observation: ObservationLink, obj: ObjectMemory) -> bool:
        if not observation.semantic_label_candidates or not obj.label_votes:
            return True
        object_top_label = max(obj.label_votes.items(), key=lambda item: item[1])[0]
        observation_top_labels = {str(label) for label in observation.semantic_label_candidates[:2]}
        if object_top_label in observation_top_labels:
            return True
        if self._compute_stability(obj) < 0.55:
            return True
        return False

    def _normalize_visible_points(self, visible_point_indices: list[int] | np.ndarray | None, point_count: int) -> set[int]:
        if visible_point_indices is None:
            return set()
        indices = np.asarray(visible_point_indices, dtype=np.int32).reshape(-1)
        indices = indices[(indices >= 0) & (indices < point_count)]
        return {int(v) for v in indices.tolist()}

    def _get_or_create_point_state(
        self, local_states: dict[int, dict[str, object]], point_index: int, stamp_sec: float
    ) -> dict[str, object]:
        state = local_states.get(point_index)
        if state is None:
            state = {
                "current_object_id": None,
                "current_score": 0.0,
                "object_scores": {},
                "last_seen_stamp": float(stamp_sec),
            }
            local_states[point_index] = state
        return state

    def _apply_positive_evidence(self, state: dict[str, object], object_id: str, weight: float) -> None:
        scores = dict(state.get("object_scores", {}))
        scores[object_id] = float(scores.get(object_id, 0.0)) + float(weight)
        for other_id in list(scores.keys()):
            if other_id == object_id:
                continue
            scores[other_id] = max(0.0, float(scores.get(other_id, 0.0)) - (self.point_score_decrement * 0.5))
        state["object_scores"] = scores

    def _apply_negative_evidence(self, state: dict[str, object], object_id: str, weight: float) -> None:
        scores = dict(state.get("object_scores", {}))
        if object_id not in scores:
            return
        scores[object_id] = max(0.0, float(scores[object_id]) - float(weight))
        state["object_scores"] = scores

    def _reconcile_point_assignment(self, state: dict[str, object]) -> str | None:
        scores = {
            str(object_id): float(score)
            for object_id, score in dict(state.get("object_scores", {})).items()
            if float(score) > 1e-6
        }
        if not scores:
            state["current_object_id"] = None
            state["current_score"] = 0.0
            state["object_scores"] = {}
            return None

        ranked = sorted(scores.items(), key=lambda item: item[1], reverse=True)
        best_object_id, best_score = ranked[0]
        second_score = ranked[1][1] if len(ranked) > 1 else 0.0
        current_object_id = state.get("current_object_id")
        current_score = float(scores.get(str(current_object_id), 0.0)) if current_object_id else 0.0

        if best_score < self.point_keep_threshold:
            state["current_object_id"] = None
            state["current_score"] = 0.0
            state["object_scores"] = scores
            return None

        if current_object_id and str(current_object_id) in scores:
            if best_object_id != current_object_id and (best_score - current_score) < self.point_reassign_margin:
                state["current_object_id"] = str(current_object_id)
                state["current_score"] = current_score
                state["object_scores"] = scores
                return str(current_object_id)

        if (best_score - second_score) < self.point_reassign_margin and current_object_id:
            state["current_object_id"] = str(current_object_id)
            state["current_score"] = current_score
            state["object_scores"] = scores
            return str(current_object_id)

        state["current_object_id"] = best_object_id
        state["current_score"] = best_score
        state["object_scores"] = scores
        return best_object_id

    def _apply_label_evidence(self, obj: ObjectMemory, label_votes: dict[str, float]) -> None:
        if obj.label_votes:
            for label in list(obj.label_votes.keys()):
                obj.label_votes[label] = float(obj.label_votes[label]) * self.label_vote_decay
                if obj.label_votes[label] <= 1e-6:
                    obj.label_votes.pop(label, None)
        for label, score in label_votes.items():
            obj.label_votes[label] = obj.label_votes.get(label, 0.0) + float(score)
        obj.stability_score = self._compute_stability(obj)

    def _refresh_supports_for_local_cloud(self, local_cloud_id: str) -> None:
        grouped_indices: dict[str, list[int]] = {}
        local_states = self.point_assignments.get(local_cloud_id, {})
        for point_index, state in local_states.items():
            object_id = state.get("current_object_id")
            current_score = float(state.get("current_score", 0.0))
            if not object_id or current_score < self.point_keep_threshold:
                continue
            grouped_indices.setdefault(str(object_id), []).append(int(point_index))

        for obj in self.objects.values():
            obj.point_support_refs = [
                (support_local_cloud_id, point_indices)
                for support_local_cloud_id, point_indices in obj.point_support_refs
                if support_local_cloud_id != local_cloud_id
            ]

        for object_id, point_indices in grouped_indices.items():
            if object_id not in self.objects:
                continue
            self.objects[object_id].point_support_refs.append(
                (local_cloud_id, sorted(set(int(v) for v in point_indices)))
            )

    def _refresh_all_supports(self) -> None:
        for obj in self.objects.values():
            obj.point_support_refs = []
        for local_cloud_id in list(self.point_assignments.keys()):
            self._refresh_supports_for_local_cloud(local_cloud_id)

    def _rebuild_global_voxel_index(self) -> None:
        voxel_index: dict[tuple[int, int, int], list[tuple[str, int]]] = {}
        for local_cloud_id, local_states in self.point_assignments.items():
            cloud_path = self._cloud_path_for_local_cloud(local_cloud_id)
            if cloud_path is None or not cloud_path.exists():
                continue
            xyz = self._load_xyz_by_id(local_cloud_id)
            if xyz is None or xyz.size == 0:
                continue
            for point_index, state in local_states.items():
                object_id = state.get("current_object_id")
                current_score = float(state.get("current_score", 0.0))
                if not object_id or current_score < self.point_keep_threshold:
                    continue
                if point_index < 0 or point_index >= xyz.shape[0]:
                    continue
                voxel_key = self._voxel_key(xyz[point_index])
                voxel_index.setdefault(voxel_key, []).append((local_cloud_id, int(point_index)))
        self.global_voxel_index = voxel_index

    def _propagate_to_historical_neighbors(
        self,
        target_object_id: str,
        source_local_cloud_id: str,
        source_xyz: np.ndarray,
        observed_point_indices: list[int],
        stamp_sec: float,
        affected_object_ids: set[str],
    ) -> None:
        visited_refs: set[tuple[str, int]] = set()
        for point_index in observed_point_indices:
            if point_index < 0 or point_index >= source_xyz.shape[0]:
                continue
            query_xyz = source_xyz[point_index]
            matched = 0
            for neighbor_voxel in self._neighbor_voxel_keys(self._voxel_key(query_xyz)):
                for ref_local_cloud_id, ref_point_index in self.global_voxel_index.get(neighbor_voxel, []):
                    ref_key = (ref_local_cloud_id, int(ref_point_index))
                    if ref_key in visited_refs:
                        continue
                    if ref_local_cloud_id == source_local_cloud_id and int(ref_point_index) == int(point_index):
                        continue
                    ref_xyz = self._point_xyz(ref_local_cloud_id, int(ref_point_index))
                    if ref_xyz is None:
                        continue
                    if float(np.linalg.norm(ref_xyz - query_xyz)) > self.cross_cloud_reassign_radius_m:
                        continue
                    state = self.point_assignments.get(ref_local_cloud_id, {}).get(int(ref_point_index))
                    if state is None:
                        continue
                    previous_object_id = state.get("current_object_id")
                    self._apply_positive_evidence(state, target_object_id, self.cross_cloud_positive_weight)
                    if previous_object_id and previous_object_id != target_object_id:
                        self._apply_negative_evidence(
                            state,
                            str(previous_object_id),
                            self.cross_cloud_negative_weight,
                        )
                    new_object_id = self._reconcile_point_assignment(state)
                    state["last_seen_stamp"] = float(stamp_sec)
                    if previous_object_id:
                        affected_object_ids.add(str(previous_object_id))
                    if new_object_id:
                        affected_object_ids.add(str(new_object_id))
                    visited_refs.add(ref_key)
                    matched += 1
                    if matched >= self.max_cross_cloud_refs_per_point:
                        break
                if matched >= self.max_cross_cloud_refs_per_point:
                    break

    def _collect_object_xyz(self, point_support_refs: list[tuple[str, list[int]]]) -> np.ndarray:
        xyz_parts: list[np.ndarray] = []
        for local_cloud_id, point_indices in point_support_refs:
            if not point_indices:
                continue
            cloud_path = self._cloud_path_for_local_cloud(local_cloud_id)
            if cloud_path is None or not cloud_path.exists():
                continue
            data = np.load(cloud_path)
            xyz = np.asarray(data["xyz"], dtype=np.float32)
            valid = np.asarray(sorted(set(int(v) for v in point_indices)), dtype=np.int32)
            valid = valid[(valid >= 0) & (valid < xyz.shape[0])]
            if valid.size == 0:
                continue
            xyz_parts.append(xyz[valid])
        if not xyz_parts:
            return np.zeros((0, 3), dtype=np.float32)
        return np.vstack(xyz_parts).astype(np.float32, copy=False)

    def _recompute_objects(self, object_ids: set[str]) -> None:
        for object_id in sorted(object_ids):
            obj = self.objects.get(object_id)
            if obj is None:
                continue
            xyz = self._collect_object_xyz(obj.point_support_refs)
            if xyz.size == 0:
                continue
            centroid = xyz.mean(axis=0).astype(np.float32)
            bbox_min = xyz.min(axis=0).astype(np.float32)
            bbox_max = xyz.max(axis=0).astype(np.float32)
            obj.centroid_world = [float(v) for v in centroid.tolist()]
            obj.bbox_world = [float(v) for v in bbox_min.tolist() + bbox_max.tolist()]
            obj.completeness_score = min(1.0, float(xyz.shape[0]) / 200.0)
            obj.stability_score = self._compute_stability(obj)
            obj.dirty_flag = True

    def _prune_point_assignments(self, stamp_sec: float) -> None:
        for local_cloud_id in list(self.point_assignments.keys()):
            local_states = self.point_assignments[local_cloud_id]
            for point_index in list(local_states.keys()):
                state = local_states[point_index]
                scores = {
                    str(object_id): float(score)
                    for object_id, score in dict(state.get("object_scores", {})).items()
                    if float(score) > 1e-6
                }
                if (stamp_sec - float(state.get("last_seen_stamp", 0.0))) > self.point_stale_time_sec:
                    scores = {
                        object_id: max(0.0, score - self.point_score_decrement)
                        for object_id, score in scores.items()
                    }
                    scores = {object_id: score for object_id, score in scores.items() if score > 1e-6}
                state["object_scores"] = scores
                self._reconcile_point_assignment(state)
                if not state.get("current_object_id") and not scores:
                    local_states.pop(point_index, None)
            if not local_states:
                self.point_assignments.pop(local_cloud_id, None)

    def _prune_objects(self) -> None:
        empty_objects: list[str] = []
        for object_id, obj in self.objects.items():
            has_support = any(len(point_indices) > 0 for _local_cloud_id, point_indices in obj.point_support_refs)
            if not has_support:
                empty_objects.append(object_id)
        for object_id in empty_objects:
            self.objects.pop(object_id, None)

    def _cloud_path_for_local_cloud(self, local_cloud_id: str) -> Path | None:
        cloud_path = self.local_cloud_paths.get(local_cloud_id)
        if not cloud_path:
            return None
        return Path(cloud_path)

    def _load_xyz_by_id(self, local_cloud_id: str) -> np.ndarray | None:
        cached = self.local_cloud_xyz_cache.get(local_cloud_id)
        if cached is not None:
            return cached
        cloud_path = self._cloud_path_for_local_cloud(local_cloud_id)
        if cloud_path is None or not cloud_path.exists():
            return None
        data = np.load(cloud_path)
        xyz = np.asarray(data["xyz"], dtype=np.float32)
        self.local_cloud_xyz_cache[local_cloud_id] = xyz
        return xyz

    def _point_xyz(self, local_cloud_id: str, point_index: int) -> np.ndarray | None:
        xyz = self._load_xyz_by_id(local_cloud_id)
        if xyz is None or point_index < 0 or point_index >= xyz.shape[0]:
            return None
        return xyz[point_index]

    def _voxel_key(self, xyz: np.ndarray) -> tuple[int, int, int]:
        return tuple(np.floor(np.asarray(xyz, dtype=np.float32) / self.spatial_voxel_size_m).astype(np.int32).tolist())

    def _neighbor_voxel_keys(self, voxel_key: tuple[int, int, int]) -> list[tuple[int, int, int]]:
        keys: list[tuple[int, int, int]] = []
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for dz in (-1, 0, 1):
                    keys.append((voxel_key[0] + dx, voxel_key[1] + dy, voxel_key[2] + dz))
        return keys
