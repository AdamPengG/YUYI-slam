from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np

from .data_types import KeyframePacket, LocalCloudPacket, SensorConfig


@dataclass
class VisibleProjection:
    visible_point_indices: np.ndarray
    projected_uv: np.ndarray
    projected_depth: np.ndarray
    visibility_score: np.ndarray


class VisibilityProjector:
    def __init__(self, depth_tolerance_m: float = 0.03) -> None:
        self.depth_tolerance_m = depth_tolerance_m

    def load_local_cloud(self, local_cloud: LocalCloudPacket) -> np.ndarray:
        cloud_path = Path(local_cloud.cloud_path)
        data = np.load(cloud_path)
        if "xyz" not in data:
            raise KeyError(f"Local cloud {cloud_path} is missing xyz")
        return np.asarray(data["xyz"], dtype=np.float32)

    def project(
        self,
        keyframe: KeyframePacket,
        local_cloud: LocalCloudPacket,
        sensor_config: SensorConfig,
        depth_m: np.ndarray | None = None,
    ) -> VisibleProjection:
        xyz_world = self.load_local_cloud(local_cloud)
        if xyz_world.size == 0:
            return VisibleProjection(
                visible_point_indices=np.zeros((0,), dtype=np.int32),
                projected_uv=np.zeros((0, 2), dtype=np.int32),
                projected_depth=np.zeros((0,), dtype=np.float32),
                visibility_score=np.zeros((0,), dtype=np.float32),
            )

        c2w = np.asarray(keyframe.t_world_cam, dtype=np.float32).reshape(4, 4)
        w2c = np.linalg.inv(c2w)
        xyz_h = np.hstack((xyz_world, np.ones((xyz_world.shape[0], 1), dtype=np.float32)))
        xyz_cam = (w2c @ xyz_h.T).T[:, :3]

        z = xyz_cam[:, 2]
        in_front = z > 0.05
        if not np.any(in_front):
            return VisibleProjection(
                visible_point_indices=np.zeros((0,), dtype=np.int32),
                projected_uv=np.zeros((0, 2), dtype=np.int32),
                projected_depth=np.zeros((0,), dtype=np.float32),
                visibility_score=np.zeros((0,), dtype=np.float32),
            )

        xyz_cam = xyz_cam[in_front]
        point_indices = np.nonzero(in_front)[0]
        fx = float(sensor_config.intrinsics["fx"])
        fy = float(sensor_config.intrinsics["fy"])
        cx = float(sensor_config.intrinsics["cx"])
        cy = float(sensor_config.intrinsics["cy"])
        width, height = int(sensor_config.image_size[0]), int(sensor_config.image_size[1])

        u = np.rint((xyz_cam[:, 0] * fx / xyz_cam[:, 2]) + cx).astype(np.int32)
        v = np.rint((xyz_cam[:, 1] * fy / xyz_cam[:, 2]) + cy).astype(np.int32)
        in_image = (u >= 0) & (u < width) & (v >= 0) & (v < height)
        if not np.any(in_image):
            return VisibleProjection(
                visible_point_indices=np.zeros((0,), dtype=np.int32),
                projected_uv=np.zeros((0, 2), dtype=np.int32),
                projected_depth=np.zeros((0,), dtype=np.float32),
                visibility_score=np.zeros((0,), dtype=np.float32),
            )

        u = u[in_image]
        v = v[in_image]
        z = xyz_cam[in_image, 2]
        point_indices = point_indices[in_image]

        pixel_id = v.astype(np.int64) * width + u.astype(np.int64)
        order = np.lexsort((z, pixel_id))
        pixel_id = pixel_id[order]
        z = z[order]
        u = u[order]
        v = v[order]
        point_indices = point_indices[order]
        _, unique_indices = np.unique(pixel_id, return_index=True)

        point_indices = point_indices[unique_indices]
        u = u[unique_indices]
        v = v[unique_indices]
        z = z[unique_indices]

        visibility = np.ones_like(z, dtype=np.float32)
        if depth_m is not None and depth_m.size > 0:
            sampled_depth = depth_m[v, u]
            finite = np.isfinite(sampled_depth) & (sampled_depth > 0.05)
            visibility = np.zeros_like(z, dtype=np.float32)
            visibility[finite] = np.clip(
                1.0 - (np.abs(sampled_depth[finite] - z[finite]) / max(self.depth_tolerance_m, 1e-4)),
                0.0,
                1.0,
            )
            depth_consistent = finite & (np.abs(sampled_depth - z) <= self.depth_tolerance_m)
            point_indices = point_indices[depth_consistent]
            u = u[depth_consistent]
            v = v[depth_consistent]
            z = z[depth_consistent]
            visibility = visibility[depth_consistent]

        return VisibleProjection(
            visible_point_indices=point_indices.astype(np.int32),
            projected_uv=np.column_stack((u, v)).astype(np.int32),
            projected_depth=z.astype(np.float32),
            visibility_score=visibility.astype(np.float32),
        )
