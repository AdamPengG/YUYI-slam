from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .data_types import LocalCloudPacket
from .io.keyframe_manifest import load_keyframe_packets
from .io.local_cloud_manifest import load_local_cloud_packets
from .io.observation_manifest import load_observation_links


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Consolidate FAST-LIVO2-guided semantic observations into a final semantic map.")
    parser.add_argument("--scene-dir", required=True)
    parser.add_argument("--export-dir", required=True)
    parser.add_argument("--prefix", default="final_observer")
    parser.add_argument("--min-instance-points", type=int, default=120)
    return parser.parse_args()


def load_clouds(local_clouds: list[LocalCloudPacket]) -> dict[str, np.ndarray]:
    clouds: dict[str, np.ndarray] = {}
    for packet in local_clouds:
        data = np.load(Path(packet.cloud_path))
        clouds[packet.local_cloud_id] = np.asarray(data["xyz"], dtype=np.float32)
    return clouds


def write_ascii_ply(path: Path, xyz: np.ndarray, rgb: np.ndarray, instance_id: np.ndarray, class_id: np.ndarray) -> None:
    header = [
        "ply",
        "format ascii 1.0",
        f"element vertex {xyz.shape[0]}",
        "property float x",
        "property float y",
        "property float z",
        "property uchar red",
        "property uchar green",
        "property uchar blue",
        "property int instance_id",
        "property int class_id",
        "end_header",
    ]
    with path.open("w", encoding="utf-8") as handle:
        handle.write("\n".join(header) + "\n")
        for point, color, ins_id, cls_id in zip(xyz, rgb, instance_id, class_id):
            handle.write(
                f"{point[0]:.6f} {point[1]:.6f} {point[2]:.6f} "
                f"{int(color[0])} {int(color[1])} {int(color[2])} {int(ins_id)} {int(cls_id)}\n"
            )


def main() -> None:
    args = parse_args()
    scene_dir = Path(args.scene_dir)
    export_dir = Path(args.export_dir)

    keyframes = load_keyframe_packets(export_dir / "keyframe_packets.jsonl")
    local_clouds = load_local_cloud_packets(export_dir / "local_cloud_packets.jsonl")
    observations = load_observation_links(export_dir / "observation_links.jsonl")
    if not keyframes:
        raise RuntimeError(f"No keyframe packets found in {export_dir}")
    if not local_clouds:
        raise RuntimeError(f"No local cloud packets found in {export_dir}")
    if not observations:
        raise RuntimeError(f"No observation links found in {export_dir}")

    cloud_lookup = load_clouds(local_clouds)
    keyframe_lookup = {packet.keyframe_id: packet for packet in keyframes}
    instance_lookup: dict[str, int] = {}
    class_lookup: dict[str, int] = {}
    class_names: list[str] = []

    xyz_parts: list[np.ndarray] = []
    rgb_parts: list[np.ndarray] = []
    instance_parts: list[np.ndarray] = []
    class_parts: list[np.ndarray] = []
    objects_summary: list[dict] = []

    for idx, observation in enumerate(observations):
        if len(observation.point_indices) < args.min_instance_points:
            continue
        cloud_xyz = cloud_lookup.get(observation.local_cloud_id)
        if cloud_xyz is None:
            continue

        pts = cloud_xyz[np.asarray(observation.point_indices, dtype=np.int32)]
        label = observation.semantic_label_candidates[0] if observation.semantic_label_candidates else "unknown"
        if label not in class_lookup:
            class_lookup[label] = len(class_lookup)
            class_names.append(label)
        class_id = class_lookup[label]

        object_id = observation.candidate_object_id or f"obs_{idx:05d}"
        if object_id not in instance_lookup:
            instance_lookup[object_id] = len(instance_lookup)
        instance_id = instance_lookup[object_id]

        seed = np.random.default_rng(instance_id)
        color = seed.integers(0, 255, size=(3,), dtype=np.uint8)

        xyz_parts.append(pts.astype(np.float32))
        rgb_parts.append(np.tile(color, (pts.shape[0], 1)))
        instance_parts.append(np.full((pts.shape[0],), instance_id, dtype=np.int32))
        class_parts.append(np.full((pts.shape[0],), class_id, dtype=np.int32))
        bbox_min = pts.min(axis=0)
        bbox_max = pts.max(axis=0)
        objects_summary.append(
            {
                "object_id": object_id,
                "instance_id": instance_id,
                "label": label,
                "keyframe_id": observation.keyframe_id,
                "local_cloud_id": observation.local_cloud_id,
                "point_count": int(pts.shape[0]),
                "bbox_world": [float(v) for v in bbox_min.tolist() + bbox_max.tolist()],
                "source_rgb_path": keyframe_lookup[observation.keyframe_id].rgb_path if observation.keyframe_id in keyframe_lookup else None,
            }
        )

    if not xyz_parts:
        raise RuntimeError("No observations survived consolidation thresholds.")

    xyz = np.vstack(xyz_parts)
    rgb = np.vstack(rgb_parts)
    instance_id = np.concatenate(instance_parts)
    class_id = np.concatenate(class_parts)

    output_cloud = scene_dir / f"{args.prefix}_semantic_cloud.ply"
    output_objects = scene_dir / f"{args.prefix}_objects.json"
    output_hydra = scene_dir / f"{args.prefix}_hydra_nodes_edges.json"
    output_summary = scene_dir / f"{args.prefix}_summary.json"

    write_ascii_ply(output_cloud, xyz, rgb, instance_id, class_id)
    output_objects.write_text(json.dumps(objects_summary, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    output_hydra.write_text(
        json.dumps(
            {
                "nodes": [
                    {
                        "id": obj["object_id"],
                        "label": obj["label"],
                        "bbox_world": obj["bbox_world"],
                    }
                    for obj in objects_summary
                ],
                "edges": [],
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )
    output_summary.write_text(
        json.dumps(
            {
                "scene_dir": str(scene_dir),
                "export_dir": str(export_dir),
                "num_keyframes": len(keyframes),
                "num_local_clouds": len(local_clouds),
                "num_observations": len(observations),
                "num_points": int(xyz.shape[0]),
                "num_objects": len(objects_summary),
                "class_names": class_names,
            },
            indent=2,
            ensure_ascii=False,
        )
        + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()
