from __future__ import annotations

import argparse
import colorsys
import json
import os
import time
from contextlib import closing
from pathlib import Path
from typing import Any

import cv2
import numpy as np
import torch
import yaml

from .data_types import KeyframePacket, LocalCloudPacket, SensorConfig
from .io.keyframe_manifest import load_keyframe_packets
from .io.local_cloud_manifest import load_local_cloud_packets
from .io.observation_manifest import append_observation_link
from .io.sensor_config import load_sensor_config
from .object_memory import ObjectMemoryStore
from .semantic_observer import MaskObservation, SemanticObserver
from .visibility_projector import VisibilityProjector


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Online semantic observer driven by FAST-LIVO2 keyframe/local-cloud manifests."
    )
    parser.add_argument("--scene-dir", required=True)
    parser.add_argument("--export-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--ovo-root", required=True)
    parser.add_argument("--ovo-config", default="data/working/configs/ovo_livo2_vanilla.yaml")
    parser.add_argument("--dataset-name", default="Replica")
    parser.add_argument("--scene-name", default=None)
    parser.add_argument("--poll-period-sec", type=float, default=5.0)
    parser.add_argument("--min-keyframes", type=int, default=5)
    parser.add_argument("--process-every-new-keyframes", type=int, default=1)
    parser.add_argument("--clear-output", action="store_true")
    parser.add_argument("--resume-if-exists", action="store_true")
    parser.add_argument("--run-once", action="store_true")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--topk-labels", type=int, default=3)
    parser.add_argument("--visibility-depth-tolerance-m", type=float, default=0.03)
    parser.add_argument("--snapshot-voxel-size-m", type=float, default=0.05)
    parser.add_argument("--snapshot-max-points", type=int, default=250000)
    parser.add_argument("--min-observation-points", type=int, default=12)
    parser.add_argument("--min-mask-area", type=int, default=64)
    parser.add_argument("--mask-erosion-px", type=int, default=2)
    parser.add_argument("--merge-centroid-radius-m", type=float, default=0.75)
    return parser.parse_args()


class OnlineSemanticAdapter:
    def __init__(
        self,
        semantic_cfg: dict[str, Any],
        class_names: list[str],
        scene_name: str,
        device: str,
        topk_labels: int,
    ) -> None:
        from ovo.entities.clip_generator import CLIPGenerator
        from ovo.entities.mask_generator import MaskGenerator

        self.device = device
        self.class_names = class_names
        self.topk_labels = max(int(topk_labels), 1)
        self.templates = semantic_cfg.get("classify_templates", ["This is a photo of a {}"])
        if isinstance(self.templates, str):
            self.templates = [self.templates]
        self.mask_generator = MaskGenerator(semantic_cfg["sam"], scene_name=scene_name, device=device)
        self.clip_generator = CLIPGenerator(semantic_cfg["clip"], device=device)
        self.text_embeddings = self._build_text_embeddings()

    def _build_text_embeddings(self) -> torch.Tensor:
        embeddings: list[torch.Tensor] = []
        for class_name in self.class_names:
            phrases = [template.format(class_name) for template in self.templates]
            embed = self.clip_generator.get_txt_embedding(phrases).mean(0, keepdim=True).float()
            embed = torch.nn.functional.normalize(embed, p=2, dim=-1)
            embeddings.append(embed.squeeze(0).cpu())
        if not embeddings:
            return torch.zeros((0, self.clip_generator.clip_dim), dtype=torch.float32)
        return torch.vstack(embeddings)

    def build_mask_observations(self, image_rgb: np.ndarray, frame_id: int) -> list[MaskObservation]:
        seg_map, binary_maps = self.mask_generator.get_masks(image_rgb, frame_id)
        if seg_map.numel() == 0 or binary_maps.numel() == 0:
            return []

        image_tensor = torch.from_numpy(image_rgb.transpose((2, 0, 1))).to(self.device)
        clip_embeds = self.clip_generator.extract_clip(
            image_tensor, binary_maps, return_all=False
        )
        if clip_embeds.numel() == 0:
            return []

        similarities = self.clip_generator.get_similarity(
            self.text_embeddings.to(clip_embeds.device, dtype=clip_embeds.dtype),
            clip_embeds.to(clip_embeds.device),
            *self.clip_generator.similarity_args,
        )
        topk = min(self.topk_labels, similarities.shape[1])
        top_scores, top_indices = torch.topk(similarities, k=topk, dim=1)
        binary_maps_np = binary_maps.detach().cpu().numpy().astype(bool, copy=False)

        observations: list[MaskObservation] = []
        for mask_idx, binary_mask in enumerate(binary_maps_np):
            ys, xs = np.nonzero(binary_mask)
            if xs.size == 0:
                continue
            bbox_xyxy = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]
            label_candidates = [
                self.class_names[int(class_idx)] for class_idx in top_indices[mask_idx].detach().cpu().tolist()
            ]
            label_scores = [float(score) for score in top_scores[mask_idx].detach().cpu().tolist()]
            observations.append(
                MaskObservation(
                    mask_id=int(mask_idx),
                    binary_mask=binary_mask,
                    bbox_xyxy=bbox_xyxy,
                    semantic_label_candidates=label_candidates,
                    semantic_scores=label_scores,
                )
            )
        return observations


class OnlineSemanticObserverRunner:
    def __init__(self, args: argparse.Namespace) -> None:
        self.args = args
        self.scene_dir = Path(args.scene_dir).expanduser().resolve()
        self.export_dir = Path(args.export_dir).expanduser().resolve()
        self.output_dir = Path(args.output_dir).expanduser().resolve()
        self.ovo_root = Path(args.ovo_root).expanduser().resolve()
        self.scene_name = args.scene_name or self.scene_dir.name
        os.chdir(self.ovo_root)

        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.state_path = self.output_dir / "observer_state.json"
        self.status_path = self.output_dir / "online_status.json"
        self.object_memory_path = self.output_dir / "object_memory.json"
        self.snapshot_path = self.output_dir / "semantic_snapshot.npz"
        self.snapshot_summary_path = self.output_dir / "semantic_snapshot_summary.txt"
        self.observation_manifest_path = self.export_dir / "observation_links.jsonl"

        self.processed_keyframe_ids: set[int] = set()
        self.total_observations = 0
        self.last_snapshot_processed = 0
        self.cloud_cache: dict[str, np.ndarray] = {}
        self.local_cloud_lookup: dict[str, LocalCloudPacket] = {}

        if args.clear_output and not args.resume_if_exists:
            self._clear_runtime_outputs()

        if args.resume_if_exists:
            self._load_state()

        semantic_cfg = self._load_ovo_config()
        self.class_names = self._load_classes()
        self.sensor_config = load_sensor_config(self.scene_dir / "sensor_config.yaml")
        self.projector = VisibilityProjector(depth_tolerance_m=args.visibility_depth_tolerance_m)
        self.observer = SemanticObserver(
            min_mask_area=args.min_mask_area,
            min_hit_points=args.min_observation_points,
            mask_erosion_px=args.mask_erosion_px,
        )
        self.object_memory = self._load_object_memory()
        self.semantic_adapter = OnlineSemanticAdapter(
            semantic_cfg=semantic_cfg,
            class_names=self.class_names,
            scene_name=self.scene_name,
            device=args.device,
            topk_labels=args.topk_labels,
        )

    def _clear_runtime_outputs(self) -> None:
        for path in [
            self.state_path,
            self.status_path,
            self.object_memory_path,
            self.snapshot_path,
            self.snapshot_summary_path,
            self.observation_manifest_path,
        ]:
            if path.exists():
                path.unlink()

    def _load_state(self) -> None:
        if not self.state_path.exists():
            return
        payload = json.loads(self.state_path.read_text(encoding="utf-8"))
        self.processed_keyframe_ids = {int(v) for v in payload.get("processed_keyframe_ids", [])}
        self.total_observations = int(payload.get("total_observations", 0))
        self.last_snapshot_processed = int(payload.get("last_snapshot_processed", 0))

    def _save_state(self) -> None:
        payload = {
            "processed_keyframe_ids": sorted(self.processed_keyframe_ids),
            "total_observations": int(self.total_observations),
            "last_snapshot_processed": int(self.last_snapshot_processed),
        }
        self.state_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    def _load_object_memory(self) -> ObjectMemoryStore:
        if self.args.resume_if_exists and self.object_memory_path.exists():
            payload = json.loads(self.object_memory_path.read_text(encoding="utf-8"))
            return ObjectMemoryStore.from_dict(payload)
        return ObjectMemoryStore(
            min_points_per_observation=self.args.min_observation_points,
            min_mask_area=self.args.min_mask_area,
            merge_centroid_radius_m=self.args.merge_centroid_radius_m,
        )

    def _save_object_memory(self) -> None:
        self.object_memory_path.write_text(
            json.dumps(self.object_memory.to_dict(), indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _load_ovo_config(self) -> dict[str, Any]:
        from ovo.utils import io_utils

        ovo_config_path = Path(self.args.ovo_config)
        if not ovo_config_path.is_absolute():
            ovo_config_path = self.ovo_root / ovo_config_path
        config = io_utils.load_config(str(ovo_config_path))
        return dict(config["semantic"])

    def _load_classes(self) -> list[str]:
        eval_info_path = self.ovo_root / "data" / "working" / "configs" / self.args.dataset_name / "eval_info.yaml"
        with eval_info_path.open("r", encoding="utf-8") as handle:
            payload = yaml.safe_load(handle)
        return list(payload.get("class_names_reduced", payload["class_names"]))

    def run(self) -> None:
        while True:
            processed = self.process_once()
            if self.args.run_once:
                return
            if not processed:
                time.sleep(self.args.poll_period_sec)

    def process_once(self) -> bool:
        keyframes = load_keyframe_packets(self.export_dir / "keyframe_packets.jsonl")
        local_clouds = {
            packet.local_cloud_id: packet
            for packet in load_local_cloud_packets(self.export_dir / "local_cloud_packets.jsonl")
        }
        self.local_cloud_lookup = local_clouds

        total_keyframes = len(keyframes)
        if total_keyframes < self.args.min_keyframes:
            self._write_status(total_keyframes, "waiting_for_keyframes", 0)
            return False

        new_packets = [packet for packet in keyframes if packet.keyframe_id not in self.processed_keyframe_ids]
        if not new_packets:
            self._write_status(total_keyframes, "idle", 0)
            return False

        processed_now = 0
        for packet in new_packets:
            local_cloud = local_clouds.get(packet.local_cloud_ref)
            if local_cloud is None:
                continue
            if not Path(packet.rgb_path).exists():
                continue
            if packet.depth_path is not None and not Path(packet.depth_path).exists():
                continue

            self._process_keyframe(packet, local_cloud)
            self.processed_keyframe_ids.add(packet.keyframe_id)
            processed_now += 1

        if processed_now == 0:
            self._write_status(total_keyframes, "waiting_for_local_clouds", 0)
            return False

        self._save_object_memory()
        self._save_state()

        processed_total = len(self.processed_keyframe_ids)
        if processed_total - self.last_snapshot_processed >= self.args.process_every_new_keyframes:
            self._export_snapshot()
            self.last_snapshot_processed = processed_total
            self._save_state()

        self._write_status(total_keyframes, "updated", processed_now)
        return True

    def _process_keyframe(self, packet: KeyframePacket, local_cloud: LocalCloudPacket) -> None:
        image_rgb = self._load_image(packet.rgb_path)
        depth_m = self._load_depth(packet.depth_path)
        projection = self.projector.project(packet, local_cloud, self.sensor_config, depth_m)
        if projection.visible_point_indices.size == 0:
            return

        mask_observations = self.semantic_adapter.build_mask_observations(image_rgb, packet.keyframe_id)
        if not mask_observations:
            return

        observations = self.observer.observe(
            keyframe_id=packet.keyframe_id,
            local_cloud_id=local_cloud.local_cloud_id,
            projection=projection,
            masks=mask_observations,
            existing_point_object_ids=self.object_memory.point_object_ids_for_local_cloud(
                local_cloud.local_cloud_id, local_cloud.point_count
            ),
        )
        if not observations:
            return

        self.object_memory.update(
            observations=observations,
            keyframe_stamp_sec=packet.stamp_sec,
            keyframe_id=packet.keyframe_id,
            local_cloud=local_cloud,
            visible_point_indices=projection.visible_point_indices.tolist(),
        )
        for observation in observations:
            append_observation_link(self.observation_manifest_path, observation)
            self.total_observations += 1

    def _load_image(self, image_path: str) -> np.ndarray:
        image_bgr = cv2.imread(str(image_path), cv2.IMREAD_COLOR)
        if image_bgr is None:
            raise RuntimeError(f"Failed to load image {image_path}")
        return cv2.cvtColor(image_bgr, cv2.COLOR_BGR2RGB)

    def _load_depth(self, depth_path: str | None) -> np.ndarray | None:
        if depth_path is None:
            return None
        depth_raw = cv2.imread(str(depth_path), cv2.IMREAD_UNCHANGED)
        if depth_raw is None:
            raise RuntimeError(f"Failed to load depth {depth_path}")
        depth_scale = float(self.sensor_config.intrinsics.get("depth_scale", 1000.0))
        return depth_raw.astype(np.float32) / max(depth_scale, 1e-6)

    def _load_cloud_xyz(self, local_cloud: LocalCloudPacket) -> np.ndarray:
        cached = self.cloud_cache.get(local_cloud.local_cloud_id)
        if cached is not None:
            return cached
        with closing(np.load(Path(local_cloud.cloud_path))) as data:
            xyz = np.asarray(data["xyz"], dtype=np.float32)
        self.cloud_cache[local_cloud.local_cloud_id] = xyz
        return xyz

    def _export_snapshot(self) -> None:
        xyz_parts: list[np.ndarray] = []
        rgb_parts: list[np.ndarray] = []
        instance_parts: list[np.ndarray] = []
        class_parts: list[np.ndarray] = []
        instance_centers: list[np.ndarray] = []
        instance_labels: list[str] = []
        instance_ids: list[int] = []
        instance_point_counts: list[int] = []
        instance_view_counts: list[int] = []

        class_lookup = {name: idx for idx, name in enumerate(self.class_names)}

        for object_index, obj in enumerate(self.object_memory.objects.values()):
            xyz = self._collect_object_points(obj.point_support_refs)
            if xyz.size == 0:
                continue
            xyz = self._voxel_downsample(xyz, self.args.snapshot_voxel_size_m)
            if xyz.size == 0:
                continue

            label = self._object_label(obj)
            class_id = int(class_lookup.get(label, -1))
            semantic_rgb = self._semantic_color(class_id)

            xyz_parts.append(xyz)
            rgb_parts.append(np.tile(semantic_rgb[None, :], (xyz.shape[0], 1)))
            instance_parts.append(np.full((xyz.shape[0],), object_index, dtype=np.int32))
            class_parts.append(np.full((xyz.shape[0],), class_id, dtype=np.int32))
            instance_centers.append(xyz.mean(axis=0).astype(np.float32))
            instance_labels.append(label)
            instance_ids.append(object_index)
            instance_point_counts.append(int(xyz.shape[0]))
            instance_view_counts.append(int(obj.observation_count))

        if not xyz_parts:
            return

        xyz = np.vstack(xyz_parts).astype(np.float32, copy=False)
        rgb = np.vstack(rgb_parts).astype(np.uint8, copy=False)
        instance_id = np.concatenate(instance_parts)
        class_id = np.concatenate(class_parts)

        if xyz.shape[0] > self.args.snapshot_max_points:
            step = int(np.ceil(xyz.shape[0] / self.args.snapshot_max_points))
            keep = np.arange(0, xyz.shape[0], step, dtype=np.int64)
            xyz = xyz[keep]
            rgb = rgb[keep]
            instance_id = instance_id[keep]
            class_id = class_id[keep]

        tmp_path = self.snapshot_path.with_name(self.snapshot_path.name + ".tmp.npz")
        np.savez_compressed(
            tmp_path,
            xyz=xyz,
            rgb=rgb,
            instance_id=instance_id,
            class_id=class_id,
            instance_ids=np.asarray(instance_ids, dtype=np.int32),
            instance_centers=np.asarray(instance_centers, dtype=np.float32),
            instance_labels=np.asarray(instance_labels, dtype=object),
            instance_point_counts=np.asarray(instance_point_counts, dtype=np.int32),
            instance_view_counts=np.asarray(instance_view_counts, dtype=np.int32),
            class_names=np.asarray(self.class_names, dtype=object),
            classify_error=np.asarray("", dtype=object),
            mode=np.asarray("semantic", dtype=object),
        )
        tmp_path.replace(self.snapshot_path)

        lines = [
            f"num_points={xyz.shape[0]}",
            f"num_instances={len(instance_ids)}",
            f"processed_keyframes={len(self.processed_keyframe_ids)}",
            f"total_observations={self.total_observations}",
        ]
        for label, center, point_count, view_count in zip(
            instance_labels[:50],
            instance_centers[:50],
            instance_point_counts[:50],
            instance_view_counts[:50],
        ):
            lines.append(
                f"label={label}, points={point_count}, views={view_count}, "
                f"center={[round(float(v), 4) for v in center.tolist()]}"
            )
        self.snapshot_summary_path.write_text("\n".join(lines) + "\n", encoding="utf-8")

    def _collect_object_points(self, point_support_refs: list[tuple[str, list[int]]]) -> np.ndarray:
        parts: list[np.ndarray] = []
        for local_cloud_id, point_indices in point_support_refs:
            local_cloud = self.local_cloud_lookup.get(local_cloud_id)
            if local_cloud is None:
                continue
            xyz = self._load_cloud_xyz(local_cloud)
            if xyz.size == 0:
                continue
            unique_indices = np.unique(np.asarray(point_indices, dtype=np.int32))
            valid = unique_indices[(unique_indices >= 0) & (unique_indices < xyz.shape[0])]
            if valid.size == 0:
                continue
            parts.append(xyz[valid])
        if not parts:
            return np.zeros((0, 3), dtype=np.float32)
        return np.vstack(parts).astype(np.float32, copy=False)

    def _voxel_downsample(self, xyz: np.ndarray, voxel_size_m: float) -> np.ndarray:
        if voxel_size_m <= 0.0 or xyz.shape[0] <= 1:
            return xyz
        voxel = np.floor(xyz / voxel_size_m).astype(np.int64)
        _, inverse = np.unique(voxel, axis=0, return_inverse=True)
        counts = np.bincount(inverse)
        sums = np.zeros((counts.shape[0], 3), dtype=np.float64)
        np.add.at(sums, inverse, xyz.astype(np.float64))
        downsampled = sums / np.maximum(counts[:, None], 1)
        return downsampled.astype(np.float32)

    def _object_label(self, obj) -> str:
        if not obj.label_votes:
            return "unknown"
        return max(obj.label_votes.items(), key=lambda item: item[1])[0]

    def _semantic_color(self, class_id: int) -> np.ndarray:
        if class_id < 0:
            return np.array([180, 180, 180], dtype=np.uint8)
        hue = (class_id * 0.137) % 1.0
        rgb = colorsys.hsv_to_rgb(hue, 0.65, 0.95)
        return np.asarray([int(255 * channel) for channel in rgb], dtype=np.uint8)

    def _write_status(self, total_keyframes: int, status: str, processed_now: int) -> None:
        payload = {
            "scene_dir": str(self.scene_dir),
            "export_dir": str(self.export_dir),
            "output_dir": str(self.output_dir),
            "status": status,
            "total_keyframes_seen": int(total_keyframes),
            "processed_keyframes": int(len(self.processed_keyframe_ids)),
            "processed_in_last_pass": int(processed_now),
            "num_objects": int(len(self.object_memory.objects)),
            "num_observations": int(self.total_observations),
            "artifact_path": str(self.snapshot_path),
        }
        self.status_path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    args = parse_args()
    runner = OnlineSemanticObserverRunner(args)
    runner.run()


if __name__ == "__main__":
    main()
