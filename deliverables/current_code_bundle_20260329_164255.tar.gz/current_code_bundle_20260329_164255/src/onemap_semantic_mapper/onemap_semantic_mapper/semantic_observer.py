from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable

import cv2
import numpy as np

from .data_types import ObservationLink
from .visibility_projector import VisibleProjection


@dataclass
class MaskObservation:
    mask_id: int
    binary_mask: np.ndarray
    bbox_xyxy: list[int]
    semantic_label_candidates: list[str]
    semantic_scores: list[float]


class SemanticObserver:
    def __init__(self, min_mask_area: int = 64, min_hit_points: int = 12, mask_erosion_px: int = 0) -> None:
        self.min_mask_area = max(int(min_mask_area), 1)
        self.min_hit_points = max(int(min_hit_points), 1)
        self.mask_erosion_px = max(int(mask_erosion_px), 0)

    def observe(
        self,
        keyframe_id: int,
        local_cloud_id: str,
        projection: VisibleProjection,
        masks: Iterable[MaskObservation | dict[str, Any]],
        existing_point_object_ids: np.ndarray | None = None,
    ) -> list[ObservationLink]:
        observations: list[ObservationLink] = []
        if projection.visible_point_indices.size == 0:
            return observations

        uv = projection.projected_uv
        visibility = projection.visibility_score

        for raw_mask in masks:
            mask = self._normalize_mask(raw_mask)
            mask_area = int(mask.binary_mask.sum())
            if mask_area < self.min_mask_area:
                continue

            hits = mask.binary_mask[uv[:, 1], uv[:, 0]]
            if hits.dtype != np.bool_:
                hits = hits.astype(bool)
            effective_min_hit_points = self._effective_min_hit_points(mask_area, mask.bbox_xyxy)
            if int(hits.sum()) < effective_min_hit_points:
                continue

            point_indices = projection.visible_point_indices[hits]
            candidate_object_id = None
            vote_count = int(hits.sum())
            if existing_point_object_ids is not None and existing_point_object_ids.size > 0:
                point_object_ids = existing_point_object_ids[point_indices]
                valid_obj_ids = np.asarray(
                    [obj_id for obj_id in point_object_ids.tolist() if obj_id is not None and str(obj_id)],
                    dtype=object,
                )
                if valid_obj_ids.size > 0:
                    values, counts = np.unique(valid_obj_ids.astype(str), return_counts=True)
                    best_idx = int(np.argmax(counts))
                    candidate_object_id = str(values[best_idx])
                    vote_count = int(counts[best_idx])

            observations.append(
                ObservationLink(
                    keyframe_id=keyframe_id,
                    mask_id=mask.mask_id,
                    local_cloud_id=local_cloud_id,
                    point_indices=[int(v) for v in point_indices.tolist()],
                    semantic_label_candidates=mask.semantic_label_candidates,
                    semantic_scores=mask.semantic_scores,
                    candidate_object_id=candidate_object_id,
                    vote_count=vote_count,
                    visibility_score=float(np.mean(visibility[hits])) if np.any(hits) else 0.0,
                    bbox_xyxy=mask.bbox_xyxy,
                    mask_area=mask_area,
                )
            )
        return observations

    def _normalize_mask(self, mask: MaskObservation | dict[str, Any]) -> MaskObservation:
        if isinstance(mask, MaskObservation):
            raw_binary_mask = np.asarray(mask.binary_mask, dtype=bool)
            bbox = [int(v) for v in mask.bbox_xyxy]
            mask_id = int(mask.mask_id)
            candidates = [str(v) for v in mask.semantic_label_candidates]
            scores = [float(v) for v in mask.semantic_scores]
        else:
            raw_binary_mask = np.asarray(mask.get("binary_mask", mask.get("segmentation")), dtype=bool)
            bbox = mask.get("bbox_xyxy")
            if bbox is None and "bbox" in mask:
                bbox_raw = mask["bbox"]
                if len(bbox_raw) == 4:
                    x0, y0, w, h = bbox_raw
                    bbox = [int(x0), int(y0), int(x0 + w), int(y0 + h)]
            mask_id = int(mask.get("mask_id", mask.get("id", 0)))
            candidates = mask.get("semantic_label_candidates", [])
            scores = mask.get("semantic_scores", [])
            if not candidates and "label" in mask:
                candidates = [str(mask["label"])]
                scores = [float(mask.get("score", 1.0))]

        binary_mask = raw_binary_mask
        raw_mask_area = int(binary_mask.sum())
        if bbox is None:
            ys, xs = np.nonzero(binary_mask)
            if xs.size == 0:
                bbox = [0, 0, 0, 0]
            else:
                bbox = [int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())]

        effective_erosion_px = self._effective_mask_erosion_px(raw_mask_area, bbox)
        if effective_erosion_px > 0 and binary_mask.any():
            kernel_size = (effective_erosion_px * 2) + 1
            kernel = np.ones((kernel_size, kernel_size), dtype=np.uint8)
            eroded = cv2.erode(binary_mask.astype(np.uint8), kernel, iterations=1)
            if int(eroded.sum()) > 0:
                binary_mask = eroded.astype(bool)

        return MaskObservation(
            mask_id=mask_id,
            binary_mask=binary_mask,
            bbox_xyxy=[int(v) for v in bbox],
            semantic_label_candidates=[str(v) for v in candidates],
            semantic_scores=[float(v) for v in scores],
        )

    def _effective_mask_erosion_px(self, mask_area: int, bbox_xyxy: list[int]) -> int:
        if self.mask_erosion_px <= 0:
            return 0
        bbox_w = max(int(bbox_xyxy[2]) - int(bbox_xyxy[0]), 0)
        bbox_h = max(int(bbox_xyxy[3]) - int(bbox_xyxy[1]), 0)
        min_side = min(bbox_w, bbox_h)
        if mask_area < max(self.min_mask_area * 3, 256) or min_side < 18:
            return 0
        if mask_area < max(self.min_mask_area * 8, 768) or min_side < 36:
            return min(self.mask_erosion_px, 1)
        return self.mask_erosion_px

    def _effective_min_hit_points(self, mask_area: int, bbox_xyxy: list[int]) -> int:
        bbox_w = max(int(bbox_xyxy[2]) - int(bbox_xyxy[0]), 0)
        bbox_h = max(int(bbox_xyxy[3]) - int(bbox_xyxy[1]), 0)
        min_side = min(bbox_w, bbox_h)
        if mask_area < max(self.min_mask_area * 3, 256) or min_side < 18:
            return max(8, min(self.min_hit_points, 8))
        if mask_area < max(self.min_mask_area * 8, 768) or min_side < 36:
            return max(8, min(self.min_hit_points, 10))
        return self.min_hit_points
