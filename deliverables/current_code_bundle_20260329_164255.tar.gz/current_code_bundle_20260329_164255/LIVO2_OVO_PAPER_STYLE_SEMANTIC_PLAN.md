# LIVO2 + OVO Paper-Style Semantic Mapping Plan

## Goal

Build a `FAST-LIVO2 + OVO` pipeline that behaves closer to the OVO paper:

- `FAST-LIVO2` stays in front as the live pose authority.
- Keyframes are exported online from the live run.
- OVO runs asynchronously in the background and incrementally updates one persistent semantic map.
- RViz shows a semantic map that keeps merging multi-view observations of the same object.
- After a room loop, the final semantic map should be clean enough that large objects are not fragmented into many small pieces.

This plan explicitly does **not** use `Gaussian-SLAM / 3DGS` for the semantic layer.  
The target is the paper-style `RGB-D keyframes + 3D segments + async semantic fusion` workflow.

## Current Gap

Current online behavior is only an approximation:

- live `FAST-LIVO2` pose works
- keyframe exporter works
- OVO output can be visualized in RViz
- but the worker still does coarse batch reruns over the whole dataset

Problems with the current approach:

- instance ids can change across reruns
- updates feel chunky instead of persistent
- same object may not grow cleanly across views
- the online map is a repeated full refresh, not a true incremental semantic state

## Target Architecture

### 1. Frontend: live geometry / pose

- Isaac Sim publishes `RGB + depth + lidar + imu`
- `FAST-LIVO2` publishes the live pose on `/aft_mapped_to_init`
- this pose remains the only geometry authority for the online semantic pipeline

### 2. Keyframe exporter

- `livo2_ovo_keyframe_exporter` keeps exporting:
  - `results/frame*.jpg`
  - `results/depth*.png`
  - `traj.txt`
  - keyframe metadata
- exported frames are already keyframes, not all raw frames

### 3. Persistent OVO semantic process

- replace full reruns with one long-lived `OVO + VanillaMapper` process
- keep one in-memory semantic map alive for the whole run
- ingest only newly exported keyframes
- preserve object instance ids across updates

### 4. Live ROS publishing

- after each incremental semantic update, publish:
  - `/ovo_semantic_map`
  - `/ovo_instance_labels`
- RViz always shows the latest whole semantic map

### 5. End-of-loop consolidation

After a loop is finished:

- flush the semantic queue
- run a final instance fusion pass
- export:
  - final semantic map checkpoint
  - final semantic snapshot
  - final semantic overview images
  - final `ply` outputs for inspection

## Implementation Stages

### Stage A. Replace batch reruns with persistent incremental worker

Deliverable:

- one new long-lived script that:
  - loads OVO config once
  - instantiates `OVO` and `VanillaMapper` once
  - watches the exported dataset directory
  - processes only new keyframes
  - periodically saves checkpoints and semantic snapshots

Why first:

- this is the main change needed to move from "batch refresh" to "paper-like online semantic growth"

### Stage B. Stable live publishing

Deliverable:

- publisher always republishes the latest snapshot
- atomic snapshot writes
- no crashes on partial writes
- stable RViz refresh behavior

Status:

- partially done already
- keep and reuse the current publisher path

### Stage C. Final-map cleanup pass

Deliverable:

- explicit end-of-run consolidation step
- remove tiny fragments
- encourage same-object merges across views
- write clean final `ply`

Status:

- first implementation completed in [final_consolidation.py](/home/peng/isacc_slam/reference/OVO/final_consolidation.py)
- current flow:
  - integrate exported keyframes with TSDF
  - project OVO semantic snapshot onto fused geometry
  - clean non-structural instances with DBSCAN largest-cluster filtering
  - export:
    - `*_semantic_segments.ply`
    - `*_instance_segments.ply`
    - `*_tsdf_mesh.ply`
    - overview images and summary

### Stage D. Quality tightening

Deliverable:

- tune keyframe density
- tune OVO thresholds for indoor room scenes
- reduce object fragmentation
- improve final room-level consistency after a loop

## Acceptance Criteria

The pipeline is considered successful when all of the following are true:

1. `FAST-LIVO2` can keep running while OVO updates in the background.
2. The semantic worker no longer reruns from scratch every time.
3. A single object observed from multiple views grows into one persistent semantic instance.
4. RViz semantic topics update repeatedly during a live run.
5. After a completed loop, the final semantic map is noticeably less fragmented than the current batch-refresh output.
6. A final semantic `ply` can be exported and visually inspected.

## Immediate Development Order

1. Add a persistent online OVO runner under `reference/OVO/`.
2. Change `ovo_async_worker` from "rerun subprocess" to "process supervisor".
3. Keep the current semantic snapshot publisher, but feed it from the persistent runner.
4. Verify live updates with the current `LIVO2 -> OVO` dataset flow.
5. Add a final consolidation/export path for loop-complete results.

## Current Commands

### Online working map

```bash
cd /home/peng/isacc_slam
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 launch onemap_semantic_mapper ovo_async_livo2.launch.py \
  launch_isaac:=False \
  scene_name:=isaac_turtlebot3_livo2_online \
  experiment_name:=isaac_livo2_online_vanilla \
  use_rviz:=True
```

### Final consolidated semantic map

```bash
cd /home/peng/isacc_slam/reference/OVO
source /home/peng/miniconda3/etc/profile.d/conda.sh
conda activate ovo5090
python final_consolidation.py \
  --scene-name isaac_turtlebot3_livo2_online \
  --experiment-name isaac_livo2_online_vanilla \
  --prefix final_tsdf
```

Expected outputs under:

- `reference/OVO/data/output/Replica/<experiment>/<scene>/final_tsdf_semantic_segments.ply`
- `reference/OVO/data/output/Replica/<experiment>/<scene>/final_tsdf_instance_segments.ply`
- `reference/OVO/data/output/Replica/<experiment>/<scene>/final_tsdf_tsdf_mesh.ply`
- `reference/OVO/data/output/Replica/<experiment>/<scene>/final_tsdf_semantic_overview.png`

## Notes

- The online map may still look rough during the loop.
- The final quality should be judged on the loop-complete consolidated output, not only on intermediate previews.
- This plan keeps geometry and semantics separated:
  - geometry comes from `FAST-LIVO2`
  - semantics comes from persistent OVO instance tracking and fusion
