#!/usr/bin/env python3

from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path

import yaml
import numpy as np


def rotation_angle_deg(r_a: np.ndarray, r_b: np.ndarray) -> float:
    r_delta = r_a.T @ r_b
    cos_theta = (np.trace(r_delta) - 1.0) * 0.5
    cos_theta = float(np.clip(cos_theta, -1.0, 1.0))
    return float(np.degrees(np.arccos(cos_theta)))


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Select non-redundant OVO keyframes from a Replica-style dataset.")
    parser.add_argument("input_scene", help="Input scene directory containing results/ and traj.txt")
    parser.add_argument("output_scene", help="Output scene directory to create")
    parser.add_argument("--translation-m", type=float, default=0.25)
    parser.add_argument("--rotation-deg", type=float, default=12.0)
    parser.add_argument("--min-frame-gap", type=int, default=5)
    parser.add_argument("--copy", action="store_true", help="Copy files instead of creating symlinks")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--source-config",
        default=None,
        help="Optional source scene yaml to copy. If omitted, inferred from data/working/configs/Replica/<scene>.yaml",
    )
    parser.add_argument(
        "--dest-config",
        default=None,
        help="Optional destination scene yaml path. If omitted, inferred from data/working/configs/Replica/<output_scene_name>.yaml",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    input_scene = Path(args.input_scene).expanduser().resolve()
    output_scene = Path(args.output_scene).expanduser().resolve()
    if not input_scene.exists():
        raise FileNotFoundError(f"Input scene not found: {input_scene}")

    results_dir = input_scene / "results"
    traj_path = input_scene / "traj.txt"
    if not results_dir.exists() or not traj_path.exists():
        raise FileNotFoundError("Input scene must contain results/ and traj.txt")

    image_paths = sorted(results_dir.glob("frame*.jpg"))
    depth_paths = sorted(results_dir.glob("depth*.png"))
    poses = np.loadtxt(traj_path).reshape(-1, 4, 4).astype(np.float32)

    if len(image_paths) != len(depth_paths) or len(image_paths) != len(poses):
        raise RuntimeError("Input scene images, depths, and poses count mismatch")

    if output_scene.exists():
        if not args.overwrite:
            raise FileExistsError(f"Output scene exists: {output_scene}. Pass --overwrite to replace it.")
        shutil.rmtree(output_scene)
    (output_scene / "results").mkdir(parents=True, exist_ok=True)

    selected_indices: list[int] = []
    last_idx: int | None = None
    last_pose: np.ndarray | None = None
    for idx, pose in enumerate(poses):
        if last_pose is None:
            selected_indices.append(idx)
            last_idx = idx
            last_pose = pose
            continue

        trans = float(np.linalg.norm(pose[:3, 3] - last_pose[:3, 3]))
        rot = rotation_angle_deg(last_pose[:3, :3], pose[:3, :3])
        gap = idx - int(last_idx)

        if gap < args.min_frame_gap and trans < args.translation_m and rot < args.rotation_deg:
            continue
        if trans < args.translation_m and rot < args.rotation_deg:
            continue

        selected_indices.append(idx)
        last_idx = idx
        last_pose = pose

    if selected_indices[-1] != len(poses) - 1:
        selected_indices.append(len(poses) - 1)

    out_traj = output_scene / "traj.txt"
    with out_traj.open("w", encoding="utf-8") as handle:
        for out_idx, src_idx in enumerate(selected_indices):
            src_image = image_paths[src_idx]
            src_depth = depth_paths[src_idx]
            dst_image = output_scene / "results" / f"frame{out_idx:06d}.jpg"
            dst_depth = output_scene / "results" / f"depth{out_idx:06d}.png"

            if args.copy:
                shutil.copy2(src_image, dst_image)
                shutil.copy2(src_depth, dst_depth)
            else:
                os.symlink(src_image, dst_image)
                os.symlink(src_depth, dst_depth)

            flattened = " ".join(f"{value:.9f}" for value in poses[src_idx].reshape(-1))
            handle.write(flattened + "\n")

    export_info = input_scene / "export_info.yaml"
    metadata = {
        "input_scene": str(input_scene),
        "selected_indices": selected_indices,
        "selection": {
            "translation_m": args.translation_m,
            "rotation_deg": args.rotation_deg,
            "min_frame_gap": args.min_frame_gap,
            "copy_mode": args.copy,
        },
    }
    if export_info.exists():
        metadata["source_export_info"] = yaml.safe_load(export_info.read_text())
    (output_scene / "selection_info.yaml").write_text(yaml.safe_dump(metadata, sort_keys=False), encoding="utf-8")

    repo_root = Path("/home/peng/isacc_slam/reference/OVO/data/working/configs/Replica")
    source_config = Path(args.source_config).expanduser().resolve() if args.source_config else repo_root / f"{input_scene.name}.yaml"
    dest_config = Path(args.dest_config).expanduser().resolve() if args.dest_config else repo_root / f"{output_scene.name}.yaml"
    if source_config.exists():
        dest_config.write_text(source_config.read_text(), encoding="utf-8")

    print(
        f"selected {len(selected_indices)} / {len(poses)} frames "
        f"from {input_scene.name} -> {output_scene.name}"
    )


if __name__ == "__main__":
    main()
