#!/usr/bin/env bash
set -euo pipefail

SCENE_NAME="${1:-isaac_turtlebot3}"
EXPERIMENT_NAME="${2:-isaac_ovo_gaussian}"
OVO_ROOT="/home/peng/isacc_slam/reference/OVO"
OVO_CONFIG="${OVO_ROOT}/data/working/configs/ovo.yaml"
SCENE_CONFIG="${OVO_ROOT}/data/working/configs/Replica/${SCENE_NAME}.yaml"
SCENE_DIR="${OVO_ROOT}/data/input/Datasets/Replica/${SCENE_NAME}"

if ! command -v conda >/dev/null 2>&1; then
  echo "conda was not found in PATH" >&2
  exit 1
fi

CONDA_BASE="$(conda info --base)"
source "${CONDA_BASE}/etc/profile.d/conda.sh"

if ! conda env list | awk '{print $1}' | grep -qx "ovo"; then
  echo "Missing conda env: ovo" >&2
  echo "Run /home/peng/isacc_slam/scripts/setup_ovo_env.sh first." >&2
  exit 1
fi

conda activate ovo

if [[ ! -d "${SCENE_DIR}/results" || ! -f "${SCENE_DIR}/traj.txt" ]]; then
  echo "Missing exported Replica-style scene at ${SCENE_DIR}" >&2
  exit 1
fi

if [[ ! -f "${SCENE_CONFIG}" ]]; then
  echo "Missing scene camera config at ${SCENE_CONFIG}" >&2
  exit 1
fi

BACKUP_CONFIG="$(mktemp)"
cp "${OVO_CONFIG}" "${BACKUP_CONFIG}"
restore_config() {
  cp "${BACKUP_CONFIG}" "${OVO_CONFIG}"
  rm -f "${BACKUP_CONFIG}"
}
trap restore_config EXIT

python - <<'PY'
from pathlib import Path
import yaml

config_path = Path("/home/peng/isacc_slam/reference/OVO/data/working/configs/ovo.yaml")
config = yaml.safe_load(config_path.read_text())
config.setdefault("slam", {})
config["slam"]["slam_module"] = "gaussian_slam"
config["slam"]["use_viewer"] = False
config.setdefault("vis", {})
config["vis"]["stream"] = False
config["vis"]["show_stream"] = False
config_path.write_text(yaml.safe_dump(config, sort_keys=False))
PY

cd "${OVO_ROOT}"
export DISABLE_WANDB=true

python run_eval.py \
  --dataset_name Replica \
  --experiment_name "${EXPERIMENT_NAME}" \
  --run \
  --scenes "${SCENE_NAME}"
