#!/usr/bin/env python3

from __future__ import annotations

import argparse
import csv
import os
import shutil
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml


REPLICA_CONFIG_ROOT = Path("/home/peng/isacc_slam/reference/OVO/data/working/configs/Replica")


@dataclass
class FrameRecord:
    saved_frame_index: int
    image_stamp_sec: float
    depth_stamp_sec: float
    odom_stamp_sec: float
    synced_frame_index: int
    image_name: str
    depth_name: str


@dataclass
class OrbKeyframe:
    timestamp: float
    c2w: np.ndarray


def quaternion_to_rotation_matrix(x: float, y: float, z: float, w: float) -> np.ndarray:
    xx, yy, zz = x * x, y * y, z * z
    xy, xz, yz = x * y, x * z, y * z
    wx, wy, wz = w * x, w * y, w * z
    return np.array(
        [
            [1.0 - 2.0 * (yy + zz), 2.0 * (xy - wz), 2.0 * (xz + wy)],
            [2.0 * (xy + wz), 1.0 - 2.0 * (xx + zz), 2.0 * (yz - wx)],
            [2.0 * (xz - wy), 2.0 * (yz + wx), 1.0 - 2.0 * (xx + yy)],
        ],
        dtype=np.float32,
    )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Build an OVO Replica scene from ORB-SLAM2 keyframe trajectory and a recorded RGB-D scene."
    )
    parser.add_argument("input_scene", help="Source Replica-style scene exported from current ROS/Isaac pipeline")
    parser.add_argument("orb_keyframe_trajectory", help="ORB2 KeyFrameTrajectory.txt in TUM format")
    parser.add_argument("output_scene", help="Destination scene directory to create")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--copy", action="store_true", help="Copy RGB/depth files instead of using symlinks")
    parser.add_argument(
        "--pose-mode",
        choices=["c2w", "w2c"],
        default="c2w",
        help="Interpret the ORB trajectory poses as camera-to-world or world-to-camera",
    )
    parser.add_argument(
        "--match-field",
        choices=["image_stamp_sec", "depth_stamp_sec", "odom_stamp_sec", "saved_frame_index"],
        default="image_stamp_sec",
        help="Field used to match ORB keyframe timestamps back to exported frames",
    )
    parser.add_argument(
        "--max-time-diff",
        type=float,
        default=0.10,
        help="Maximum timestamp difference allowed when matching ORB keyframes to exported frames",
    )
    parser.add_argument(
        "--source-config",
        default=None,
        help="Optional source scene yaml to copy. Defaults to configs/Replica/<input_scene_name>.yaml",
    )
    parser.add_argument(
        "--dest-config",
        default=None,
        help="Optional destination scene yaml path. Defaults to configs/Replica/<output_scene_name>.yaml",
    )
    return parser.parse_args()


def invert_pose(pose: np.ndarray) -> np.ndarray:
    rotation = pose[:3, :3]
    translation = pose[:3, 3]
    inv = np.eye(4, dtype=np.float32)
    inv[:3, :3] = rotation.T
    inv[:3, 3] = -rotation.T @ translation
    return inv


def load_orb_keyframes(path: Path, pose_mode: str) -> list[OrbKeyframe]:
    keyframes: list[OrbKeyframe] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 8:
            continue
        timestamp, tx, ty, tz, qx, qy, qz, qw = map(float, parts[:8])
        pose = np.eye(4, dtype=np.float32)
        pose[:3, :3] = quaternion_to_rotation_matrix(qx, qy, qz, qw)
        pose[:3, 3] = np.array([tx, ty, tz], dtype=np.float32)
        if pose_mode == "w2c":
            pose = invert_pose(pose)
        keyframes.append(OrbKeyframe(timestamp=timestamp, c2w=pose))
    if not keyframes:
        raise RuntimeError(f"No valid ORB keyframes found in {path}")
    return keyframes


def load_frame_records(scene_dir: Path) -> list[FrameRecord]:
    frame_index_path = scene_dir / "frames_index.csv"
    if frame_index_path.exists():
        records: list[FrameRecord] = []
        with frame_index_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                records.append(
                    FrameRecord(
                        saved_frame_index=int(row["saved_frame_index"]),
                        image_stamp_sec=float(row["image_stamp_sec"]),
                        depth_stamp_sec=float(row["depth_stamp_sec"]),
                        odom_stamp_sec=float(row["odom_stamp_sec"]),
                        synced_frame_index=int(row["synced_frame_index"]),
                        image_name=row["image_name"],
                        depth_name=row["depth_name"],
                    )
                )
        records.sort(key=lambda item: item.saved_frame_index)
        return records

    results_dir = scene_dir / "results"
    image_paths = sorted(results_dir.glob("frame*.jpg"))
    depth_paths = sorted(results_dir.glob("depth*.png"))
    if len(image_paths) != len(depth_paths):
        raise RuntimeError("Source scene results/ is inconsistent and has different RGB/depth counts")

    records = []
    for index, (image_path, depth_path) in enumerate(zip(image_paths, depth_paths)):
        records.append(
            FrameRecord(
                saved_frame_index=index,
                image_stamp_sec=float(index),
                depth_stamp_sec=float(index),
                odom_stamp_sec=float(index),
                synced_frame_index=index,
                image_name=image_path.name,
                depth_name=depth_path.name,
            )
        )
    return records


def infer_source_config(input_scene: Path, override: str | None) -> Path:
    if override is not None:
        return Path(override).expanduser().resolve()
    return REPLICA_CONFIG_ROOT / f"{input_scene.name}.yaml"


def infer_dest_config(output_scene: Path, override: str | None) -> Path:
    if override is not None:
        return Path(override).expanduser().resolve()
    return REPLICA_CONFIG_ROOT / f"{output_scene.name}.yaml"


def find_best_frame_match(records: list[FrameRecord], keyframe_timestamp: float, field_name: str, max_time_diff: float) -> tuple[FrameRecord, float]:
    best = min(records, key=lambda record: abs(float(getattr(record, field_name)) - keyframe_timestamp))
    diff = abs(float(getattr(best, field_name)) - keyframe_timestamp)
    if field_name != "saved_frame_index" and diff > max_time_diff:
        raise RuntimeError(
            f"Failed to match ORB keyframe timestamp {keyframe_timestamp:.6f}s within {max_time_diff:.3f}s; best diff was {diff:.6f}s"
        )
    return best, diff


def main() -> None:
    args = parse_args()
    input_scene = Path(args.input_scene).expanduser().resolve()
    output_scene = Path(args.output_scene).expanduser().resolve()
    orb_keyframe_trajectory = Path(args.orb_keyframe_trajectory).expanduser().resolve()

    if not input_scene.exists():
        raise FileNotFoundError(f"Input scene not found: {input_scene}")
    if not orb_keyframe_trajectory.exists():
        raise FileNotFoundError(f"ORB keyframe trajectory not found: {orb_keyframe_trajectory}")

    if output_scene.exists():
        if not args.overwrite:
            raise FileExistsError(f"Output scene already exists: {output_scene}. Pass --overwrite to replace it.")
        shutil.rmtree(output_scene)

    results_dir = output_scene / "results"
    results_dir.mkdir(parents=True, exist_ok=True)

    frame_records = load_frame_records(input_scene)
    orb_keyframes = load_orb_keyframes(orb_keyframe_trajectory, args.pose_mode)

    source_results_dir = input_scene / "results"
    matched_rows: list[dict[str, object]] = []
    selected_source_indices: set[int] = set()
    output_traj_lines: list[str] = []

    frame_index_path = output_scene / "frames_index.csv"
    frame_index_file = frame_index_path.open("w", encoding="utf-8", newline="")
    frame_index_writer = csv.writer(frame_index_file)
    frame_index_writer.writerow(
        [
            "saved_frame_index",
            "image_stamp_sec",
            "depth_stamp_sec",
            "odom_stamp_sec",
            "synced_frame_index",
            "image_name",
            "depth_name",
            "source_saved_frame_index",
            "orb_timestamp_sec",
            "match_diff_sec",
        ]
    )

    output_index = 0
    try:
        for orb_index, keyframe in enumerate(orb_keyframes):
            record, diff = find_best_frame_match(frame_records, keyframe.timestamp, args.match_field, args.max_time_diff)
            if record.saved_frame_index in selected_source_indices:
                continue
            selected_source_indices.add(record.saved_frame_index)

            src_image = source_results_dir / record.image_name
            src_depth = source_results_dir / record.depth_name
            dst_image = results_dir / f"frame{output_index:06d}.jpg"
            dst_depth = results_dir / f"depth{output_index:06d}.png"

            if args.copy:
                shutil.copy2(src_image, dst_image)
                shutil.copy2(src_depth, dst_depth)
            else:
                os.symlink(src_image, dst_image)
                os.symlink(src_depth, dst_depth)

            output_traj_lines.append(" ".join(f"{value:.9f}" for value in keyframe.c2w.reshape(-1)))
            frame_index_writer.writerow(
                [
                    output_index,
                    f"{record.image_stamp_sec:.9f}",
                    f"{record.depth_stamp_sec:.9f}",
                    f"{record.odom_stamp_sec:.9f}",
                    record.synced_frame_index,
                    dst_image.name,
                    dst_depth.name,
                    record.saved_frame_index,
                    f"{keyframe.timestamp:.9f}",
                    f"{diff:.9f}",
                ]
            )
            matched_rows.append(
                {
                    "output_saved_frame_index": output_index,
                    "source_saved_frame_index": record.saved_frame_index,
                    "orb_timestamp_sec": keyframe.timestamp,
                    "match_diff_sec": diff,
                }
            )
            output_index += 1
    finally:
        frame_index_file.close()

    if not matched_rows:
        raise RuntimeError("No ORB keyframes could be matched to source frames")

    (output_scene / "traj.txt").write_text("\n".join(output_traj_lines) + "\n", encoding="utf-8")

    source_export_info = None
    export_info_path = input_scene / "export_info.yaml"
    if export_info_path.exists():
        source_export_info = yaml.safe_load(export_info_path.read_text(encoding="utf-8"))

    selection_info = {
        "input_scene": str(input_scene),
        "orb_keyframe_trajectory": str(orb_keyframe_trajectory),
        "pose_mode": args.pose_mode,
        "match_field": args.match_field,
        "max_time_diff": args.max_time_diff,
        "selected_keyframes": len(matched_rows),
        "matched_rows": matched_rows,
        "copy_mode": args.copy,
    }
    if source_export_info is not None:
        selection_info["source_export_info"] = source_export_info
    (output_scene / "selection_info.yaml").write_text(yaml.safe_dump(selection_info, sort_keys=False), encoding="utf-8")

    source_config = infer_source_config(input_scene, args.source_config)
    dest_config = infer_dest_config(output_scene, args.dest_config)
    if source_config.exists():
        dest_config.write_text(source_config.read_text(encoding="utf-8"), encoding="utf-8")

    print(
        f"matched {len(matched_rows)} ORB keyframes from {orb_keyframe_trajectory.name} "
        f"into OVO scene {output_scene.name}"
    )


if __name__ == "__main__":
    main()
