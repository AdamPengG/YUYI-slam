#!/usr/bin/env bash
set -euo pipefail

WORKSPACE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MIRROR_REPO="${HOME}/.cache/gitnexus_mirrors/isacc_slam"
GITNEXUS_BIN="${GITNEXUS_BIN:-${HOME}/.local/bin/gitnexus}"

usage() {
  cat <<'EOF'
Usage:
  bash scripts/run_gitnexus_isacc_slam.sh sync
  bash scripts/run_gitnexus_isacc_slam.sh analyze [--force]
  bash scripts/run_gitnexus_isacc_slam.sh status
  bash scripts/run_gitnexus_isacc_slam.sh clean
  bash scripts/run_gitnexus_isacc_slam.sh list
  bash scripts/run_gitnexus_isacc_slam.sh mcp
  bash scripts/run_gitnexus_isacc_slam.sh serve
  bash scripts/run_gitnexus_isacc_slam.sh shell

This workspace is not a top-level git repo, so the script mirrors the
project into ~/.cache/gitnexus_mirrors/isacc_slam and runs GitNexus there.
EOF
}

require_gitnexus() {
  if [[ ! -x "${GITNEXUS_BIN}" ]]; then
    echo "Missing gitnexus wrapper at ${GITNEXUS_BIN}" >&2
    exit 1
  fi
}

sync_mirror() {
  mkdir -p "${MIRROR_REPO}"

  rsync -a --delete \
    --exclude '.git/' \
    --exclude '.gitnexus/' \
    --exclude 'build/' \
    --exclude 'install/' \
    --exclude 'log/' \
    --exclude 'local/' \
    --exclude '__pycache__/' \
    --exclude '.pytest_cache/' \
    --exclude '.mypy_cache/' \
    --exclude '*.pyc' \
    --exclude '*.pt' \
    --exclude 'third_party/Sophus/build/' \
    "${WORKSPACE_ROOT}/" "${MIRROR_REPO}/"

  if [[ ! -d "${MIRROR_REPO}/.git" ]]; then
    git -C "${MIRROR_REPO}" init -q
    git -C "${MIRROR_REPO}" config user.name "$(git config --global user.name)"
    git -C "${MIRROR_REPO}" config user.email "$(git config --global user.email)"
  fi

  cat > "${MIRROR_REPO}/.git/info/exclude" <<'EOF'
/.gitnexus
/AGENTS.md
/CLAUDE.md
/.claude
EOF

  git -C "${MIRROR_REPO}" rm -rq --cached --ignore-unmatch \
    .gitnexus AGENTS.md CLAUDE.md .claude || true

  git -C "${MIRROR_REPO}" add -A
  if ! git -C "${MIRROR_REPO}" diff --cached --quiet; then
    git -C "${MIRROR_REPO}" commit -q -m "Mirror sync $(date '+%Y-%m-%d %H:%M:%S')"
  fi
}

run_in_mirror() {
  local cmd="$1"
  shift
  cd "${MIRROR_REPO}"
  "${GITNEXUS_BIN}" "${cmd}" "$@"
}

main() {
  require_gitnexus

  local cmd="${1:-}"
  if [[ -z "${cmd}" ]]; then
    usage
    exit 1
  fi
  shift || true

  case "${cmd}" in
    sync)
      sync_mirror
      ;;
    analyze)
      sync_mirror
      run_in_mirror analyze "$@"
      ;;
    status|clean)
      sync_mirror
      run_in_mirror "${cmd}" "$@"
      ;;
    list|mcp|serve)
      run_in_mirror "${cmd}" "$@"
      ;;
    shell)
      sync_mirror
      cd "${MIRROR_REPO}"
      exec "${SHELL:-/bin/bash}"
      ;;
    help|-h|--help)
      usage
      ;;
    *)
      echo "Unknown command: ${cmd}" >&2
      usage
      exit 1
      ;;
  esac
}

main "$@"
