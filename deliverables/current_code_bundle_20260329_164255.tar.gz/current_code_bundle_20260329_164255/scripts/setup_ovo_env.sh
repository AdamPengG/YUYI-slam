#!/usr/bin/env bash
set -euo pipefail

OVO_ROOT="/home/peng/isacc_slam/reference/OVO"

retry_cmd() {
  local attempts="$1"
  shift
  local try=1
  until "$@"; do
    if [[ "${try}" -ge "${attempts}" ]]; then
      return 1
    fi
    echo "Command failed, retrying (${try}/${attempts})..." >&2
    try=$((try + 1))
    sleep 5
  done
}

if ! command -v conda >/dev/null 2>&1; then
  echo "conda was not found in PATH" >&2
  exit 1
fi

CONDA_BASE="$(conda info --base)"
source "${CONDA_BASE}/etc/profile.d/conda.sh"

if ! conda env list | awk '{print $1}' | grep -qx "ovo"; then
  conda create -y -n ovo python=3.11
fi

conda activate ovo

export CONDA_REMOTE_CONNECT_TIMEOUT_SECS=30
export CONDA_REMOTE_READ_TIMEOUT_SECS=120
export CONDA_REMOTE_MAX_RETRIES=10
export CONDA_REMOTE_BACKOFF_FACTOR=2
export PIP_DEFAULT_TIMEOUT=120

retry_cmd 3 conda install -y -c conda-forge \
  pyyaml tqdm psutil plyfile numpy=2.4 matplotlib seaborn opencv=4.11 imageio scipy scikit-learn pandas

retry_cmd 3 pip install wandb==0.25.1

retry_cmd 3 pip install \
  torch==2.5.1 \
  torchvision==0.20.1 \
  transformers==4.51.0 \
  open_clip_torch==2.32.0 \
  open3d==0.19.0 \
  huggingface-hub==0.30.1 \
  einops==0.8.1

pushd "${OVO_ROOT}/thirdParty/segment-anything-2" >/dev/null
retry_cmd 3 pip install -e .
popd >/dev/null

pushd "${OVO_ROOT}/thirdParty/perception_models" >/dev/null
retry_cmd 3 pip install -e . --no-dependencies
popd >/dev/null

retry_cmd 3 conda install -y -c pytorch -c conda-forge faiss-gpu=1.8.0 cudnn
retry_cmd 3 conda install -y -c nvidia/label/cuda-12.1.0 cuda-toolkit=12.1

retry_cmd 3 pip install \
  git+https://github.com/VladimirYugay/simple-knn.git@c7e51a06a4cd84c25e769fee29ab391fe5d5ff8d \
  git+https://github.com/VladimirYugay/gaussian_rasterizer.git@9c40173fcc8d9b16778a1a8040295bc2f9
